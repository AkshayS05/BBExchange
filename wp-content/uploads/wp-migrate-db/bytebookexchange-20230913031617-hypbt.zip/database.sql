# WordPress MySQL database migration
#
# Generated: Wednesday 13. September 2023 03:16 UTC
# Hostname: localhost
# Database: `local`
# URL: //bytebookexchange
# Path: C:\\Users\\Akshay\\Local Sites\\bytebookexchange\\app\\public
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, campus, event, instructor, like, nav_menu_item, note, page, post, post_like, post_liked, program, wp_navigation
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2023-08-19 17:17:20', '2023-08-19 17:17:20', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://en.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=864 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://bytebookexchange', 'yes'),
(2, 'home', 'http://bytebookexchange', 'yes'),
(3, 'blogname', 'ByteBookExchange', 'yes'),
(4, 'blogdescription', '&quot;Connecting Developers Through Bytes of Knowledge&quot;', 'yes'),
(5, 'users_can_register', '1', 'yes'),
(6, 'admin_email', 'akshaysharma5432@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:231:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:9:"events/?$";s:25:"index.php?post_type=event";s:39:"events/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=event&feed=$matches[1]";s:34:"events/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=event&feed=$matches[1]";s:26:"events/page/([0-9]{1,})/?$";s:43:"index.php?post_type=event&paged=$matches[1]";s:11:"programs/?$";s:27:"index.php?post_type=program";s:41:"programs/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=program&feed=$matches[1]";s:36:"programs/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=program&feed=$matches[1]";s:28:"programs/page/([0-9]{1,})/?$";s:45:"index.php?post_type=program&paged=$matches[1]";s:11:"campuses/?$";s:26:"index.php?post_type=campus";s:41:"campuses/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?post_type=campus&feed=$matches[1]";s:36:"campuses/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?post_type=campus&feed=$matches[1]";s:28:"campuses/page/([0-9]{1,})/?$";s:44:"index.php?post_type=campus&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:34:"events/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"events/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"events/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"events/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"events/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"events/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:23:"events/([^/]+)/embed/?$";s:38:"index.php?event=$matches[1]&embed=true";s:27:"events/([^/]+)/trackback/?$";s:32:"index.php?event=$matches[1]&tb=1";s:47:"events/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?event=$matches[1]&feed=$matches[2]";s:42:"events/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?event=$matches[1]&feed=$matches[2]";s:35:"events/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?event=$matches[1]&paged=$matches[2]";s:42:"events/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?event=$matches[1]&cpage=$matches[2]";s:31:"events/([^/]+)(?:/([0-9]+))?/?$";s:44:"index.php?event=$matches[1]&page=$matches[2]";s:23:"events/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:33:"events/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:53:"events/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"events/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"events/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:29:"events/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:36:"programs/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"programs/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"programs/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"programs/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"programs/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"programs/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:25:"programs/([^/]+)/embed/?$";s:40:"index.php?program=$matches[1]&embed=true";s:29:"programs/([^/]+)/trackback/?$";s:34:"index.php?program=$matches[1]&tb=1";s:49:"programs/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?program=$matches[1]&feed=$matches[2]";s:44:"programs/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?program=$matches[1]&feed=$matches[2]";s:37:"programs/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?program=$matches[1]&paged=$matches[2]";s:44:"programs/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?program=$matches[1]&cpage=$matches[2]";s:33:"programs/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?program=$matches[1]&page=$matches[2]";s:25:"programs/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:35:"programs/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:55:"programs/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"programs/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"programs/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:31:"programs/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:38:"instructor/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:48:"instructor/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:68:"instructor/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:63:"instructor/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:63:"instructor/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:44:"instructor/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:27:"instructor/([^/]+)/embed/?$";s:43:"index.php?instructor=$matches[1]&embed=true";s:31:"instructor/([^/]+)/trackback/?$";s:37:"index.php?instructor=$matches[1]&tb=1";s:39:"instructor/([^/]+)/page/?([0-9]{1,})/?$";s:50:"index.php?instructor=$matches[1]&paged=$matches[2]";s:46:"instructor/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?instructor=$matches[1]&cpage=$matches[2]";s:35:"instructor/([^/]+)(?:/([0-9]+))?/?$";s:49:"index.php?instructor=$matches[1]&page=$matches[2]";s:27:"instructor/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"instructor/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"instructor/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"instructor/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"instructor/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"instructor/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:36:"campuses/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"campuses/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"campuses/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"campuses/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"campuses/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"campuses/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:25:"campuses/([^/]+)/embed/?$";s:39:"index.php?campus=$matches[1]&embed=true";s:29:"campuses/([^/]+)/trackback/?$";s:33:"index.php?campus=$matches[1]&tb=1";s:49:"campuses/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?campus=$matches[1]&feed=$matches[2]";s:44:"campuses/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?campus=$matches[1]&feed=$matches[2]";s:37:"campuses/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?campus=$matches[1]&paged=$matches[2]";s:44:"campuses/([^/]+)/comment-page-([0-9]{1,})/?$";s:46:"index.php?campus=$matches[1]&cpage=$matches[2]";s:33:"campuses/([^/]+)(?:/([0-9]+))?/?$";s:45:"index.php?campus=$matches[1]&page=$matches[2]";s:25:"campuses/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:35:"campuses/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:55:"campuses/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"campuses/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"campuses/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:31:"campuses/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:32:"note/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"note/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"note/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"note/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"note/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"note/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:21:"note/([^/]+)/embed/?$";s:37:"index.php?note=$matches[1]&embed=true";s:25:"note/([^/]+)/trackback/?$";s:31:"index.php?note=$matches[1]&tb=1";s:33:"note/([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?note=$matches[1]&paged=$matches[2]";s:40:"note/([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?note=$matches[1]&cpage=$matches[2]";s:29:"note/([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?note=$matches[1]&page=$matches[2]";s:21:"note/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:31:"note/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:51:"note/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"note/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"note/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:27:"note/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:32:"like/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"like/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"like/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"like/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"like/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"like/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:21:"like/([^/]+)/embed/?$";s:37:"index.php?like=$matches[1]&embed=true";s:25:"like/([^/]+)/trackback/?$";s:31:"index.php?like=$matches[1]&tb=1";s:33:"like/([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?like=$matches[1]&paged=$matches[2]";s:40:"like/([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?like=$matches[1]&cpage=$matches[2]";s:29:"like/([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?like=$matches[1]&page=$matches[2]";s:21:"like/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:31:"like/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:51:"like/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"like/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"like/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:27:"like/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:37:"postlikes/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"postlikes/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"postlikes/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"postlikes/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"postlikes/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"postlikes/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"postlikes/([^/]+)/embed/?$";s:42:"index.php?postlikes=$matches[1]&embed=true";s:30:"postlikes/([^/]+)/trackback/?$";s:36:"index.php?postlikes=$matches[1]&tb=1";s:38:"postlikes/([^/]+)/page/?([0-9]{1,})/?$";s:49:"index.php?postlikes=$matches[1]&paged=$matches[2]";s:45:"postlikes/([^/]+)/comment-page-([0-9]{1,})/?$";s:49:"index.php?postlikes=$matches[1]&cpage=$matches[2]";s:34:"postlikes/([^/]+)(?:/([0-9]+))?/?$";s:48:"index.php?postlikes=$matches[1]&page=$matches[2]";s:26:"postlikes/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"postlikes/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"postlikes/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"postlikes/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"postlikes/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:32:"postlikes/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=41&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:6:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:51:"all-in-one-wp-migration/all-in-one-wp-migration.php";i:2;s:39:"manual-image-crop/manual-image-crop.php";i:3;s:19:"members/members.php";i:4;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";i:5;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'ByteBookExchange', 'yes'),
(41, 'stylesheet', 'ByteBookExchange', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '55853', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:0:{}', 'yes'),
(77, 'widget_text', 'a:0:{}', 'yes'),
(78, 'widget_rss', 'a:0:{}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '43', 'yes'),
(82, 'page_on_front', '41', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1708017432', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '55853', 'yes'),
(100, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:96:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:16:"restrict_content";b:1;s:10:"list_roles";b:1;s:12:"create_roles";b:1;s:12:"delete_roles";b:1;s:10:"edit_roles";b:1;s:13:"delete_events";b:1;s:20:"delete_others_events";b:1;s:21:"delete_private_events";b:1;s:23:"delete_published_events";b:1;s:11:"edit_events";b:1;s:18:"edit_others_events";b:1;s:19:"edit_private_events";b:1;s:21:"edit_published_events";b:1;s:14:"publish_events";b:1;s:19:"read_private_events";b:1;s:14:"delete_campuss";b:1;s:21:"delete_others_campuss";b:1;s:22:"delete_private_campuss";b:1;s:24:"delete_published_campuss";b:1;s:12:"edit_campuss";b:1;s:19:"edit_others_campuss";b:1;s:20:"edit_private_campuss";b:1;s:22:"edit_published_campuss";b:1;s:15:"publish_campuss";b:1;s:20:"read_private_campuss";b:1;s:10:"edit_notes";b:1;s:17:"edit_others_notes";b:1;s:12:"delete_notes";b:1;s:13:"publish_notes";b:1;s:18:"read_private_notes";b:1;s:20:"delete_private_notes";b:1;s:22:"delete_published_notes";b:1;s:19:"delete_others_notes";b:1;s:18:"edit_private_notes";b:1;s:20:"edit_published_notes";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:5:{s:4:"read";b:1;s:7:"level_0";b:1;s:12:"delete_notes";b:1;s:10:"edit_notes";b:1;s:13:"publish_notes";b:1;}}s:13:"event_planner";a:2:{s:4:"name";s:13:"Event Planner";s:12:"capabilities";a:11:{s:4:"read";b:1;s:11:"edit_events";b:1;s:18:"edit_others_events";b:1;s:13:"delete_events";b:1;s:14:"publish_events";b:1;s:19:"read_private_events";b:1;s:21:"delete_private_events";b:1;s:23:"delete_published_events";b:1;s:20:"delete_others_events";b:1;s:19:"edit_private_events";b:1;s:21:"edit_published_events";b:1;}}s:14:"campus_manager";a:2:{s:4:"name";s:14:"Campus Manager";s:12:"capabilities";a:11:{s:4:"read";b:1;s:12:"edit_campuss";b:1;s:19:"edit_others_campuss";b:1;s:14:"delete_campuss";b:1;s:15:"publish_campuss";b:1;s:20:"read_private_campuss";b:1;s:22:"delete_private_campuss";b:1;s:24:"delete_published_campuss";b:1;s:21:"delete_others_campuss";b:1;s:20:"edit_private_campuss";b:1;s:22:"edit_published_campuss";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes'),
(102, 'user_count', '3', 'no'),
(103, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(104, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(105, 'cron', 'a:9:{i:1694576290;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1694582245;a:4:{s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1694582379;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1694590965;a:1:{s:21:"ai1wm_storage_cleanup";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1694625444;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1694625579;a:3:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1694888516;a:1:{s:30:"wp_delete_temp_updater_backups";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1694971044;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(121, 'nonce_key', 'h=3;G=LO{0&kwSYTB%e{pX=.`nL]>b(sq:{*Y^Mnbc4fwu|ux{?6;:I>dw7ZdJ5(', 'no'),
(122, 'nonce_salt', '_;P,TyYk~-dN9WLaX+VTr^c$>=NB^-g&&uy}%y;!p$PQ[: p$}flp{-_Kv}doy%r', 'no'),
(124, 'recovery_keys', 'a:2:{s:22:"fB7mJRDHIBq47Sx5swCkID";a:2:{s:10:"hashed_key";s:34:"$P$BC5eUPy.gnitlYlDtFMEW5hkYpmJcZ/";s:10:"created_at";i:1694479190;}s:22:"fOruRsjYiimgW89o9ek5EZ";a:2:{s:10:"hashed_key";s:34:"$P$Bzqm.14zEIQcLyMM5gU26rI1rdt6.d1";s:10:"created_at";i:1694570619;}}', 'yes'),
(125, 'theme_mods_twentytwentythree', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1692468097;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(126, 'https_detection_errors', 'a:1:{s:23:"ssl_verification_failed";a:1:{i:0;s:24:"SSL verification failed.";}}', 'yes'),
(138, 'can_compress_scripts', '0', 'yes'),
(153, 'finished_updating_comment_type', '1', 'yes'),
(158, 'current_theme', 'Byte Book Exchange', 'yes'),
(159, 'theme_mods_ByteBookExchange', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:3:{s:18:"headerMenuLocation";i:2;s:21:"footerMenuLocationOne";i:3;s:21:"footerMenuLocationTwo";i:4;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(160, 'theme_switched', '', 'yes'),
(165, 'WPLANG', '', 'yes'),
(166, 'new_admin_email', 'akshaysharma5432@gmail.com', 'yes'),
(173, 'wp_calendar_block_has_published_posts', '1', 'yes'),
(208, 'recovery_mode_email_last_sent', '1694570619', 'yes'),
(209, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(246, 'category_children', 'a:0:{}', 'yes'),
(280, 'recently_activated', 'a:0:{}', 'yes'),
(286, 'acf_version', '6.2.1', 'yes'),
(367, 'mic_make2x', 'true', 'yes'),
(476, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:26:"akshaysharma5432@gmail.com";s:7:"version";s:5:"6.3.1";s:9:"timestamp";i:1693329574;}', 'no'),
(600, 'members_activated', '1694022932', 'yes'),
(601, 'members_addons_migrated', '1', 'yes'),
(602, 'widget_members-widget-login', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(603, 'widget_members-widget-users', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(605, 'members_notifications', 'a:4:{s:6:"update";i:1694566463;s:4:"feed";a:0:{}s:6:"events";a:0:{}s:9:"dismissed";a:0:{}}', 'yes'),
(732, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1694574977;}', 'no'),
(752, 'ai1wm_secret_key', 'f1lGkx6Ge8fe', 'yes'),
(754, 'ai1wm_status', 'a:2:{s:4:"type";s:8:"download";s:7:"message";s:343:"<a href="http://bytebookexchange.comwp-content/ai1wm-backups/bytebookexchange.local-20230912-032424-axy4qp.wpress" class="ai1wm-button-green ai1wm-emphasize ai1wm-button-download" title="bytebookexchange.local" download="bytebookexchange.local-20230912-032424-axy4qp.wpress"><span>Download bytebookexchange.local</span><em>Size: 66 MB</em></a>";}', 'yes'),
(760, 'ai1wm_updater', 'a:0:{}', 'yes'),
(770, 'ai1wm_backups_labels', 'a:0:{}', 'yes'),
(852, 'blog_public', '1', 'yes'),
(853, 'upload_path', '', 'yes'),
(854, 'upload_url_path', '', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=755 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(4, 7, '_edit_lock', '1692470156:1'),
(7, 9, '_edit_lock', '1692846769:1'),
(10, 11, '_edit_lock', '1692471273:1'),
(12, 14, '_edit_lock', '1692486818:1'),
(13, 15, '_edit_lock', '1692487048:1'),
(14, 14, '_wp_trash_meta_status', 'draft'),
(15, 14, '_wp_trash_meta_time', '1692487068'),
(16, 14, '_wp_desired_post_slug', ''),
(17, 15, '_wp_trash_meta_status', 'draft'),
(18, 15, '_wp_trash_meta_time', '1692487068'),
(19, 15, '_wp_desired_post_slug', ''),
(20, 18, '_edit_lock', '1693068750:1'),
(21, 3, '_edit_lock', '1692487034:1'),
(24, 23, '_edit_lock', '1692499004:1'),
(25, 25, '_edit_lock', '1692501998:1'),
(26, 27, '_edit_lock', '1692499062:1'),
(27, 29, '_menu_item_type', 'custom'),
(28, 29, '_menu_item_menu_item_parent', '0'),
(29, 29, '_menu_item_object_id', '29'),
(30, 29, '_menu_item_object', 'custom'),
(31, 29, '_menu_item_target', ''),
(32, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(33, 29, '_menu_item_xfn', ''),
(34, 29, '_menu_item_url', 'http://bytebookexchange.com'),
(35, 29, '_menu_item_orphaned', '1692502177'),
(36, 30, '_menu_item_type', 'post_type'),
(37, 30, '_menu_item_menu_item_parent', '0'),
(38, 30, '_menu_item_object_id', '3'),
(39, 30, '_menu_item_object', 'page'),
(40, 30, '_menu_item_target', ''),
(41, 30, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(42, 30, '_menu_item_xfn', ''),
(43, 30, '_menu_item_url', ''),
(45, 31, '_menu_item_type', 'post_type'),
(46, 31, '_menu_item_menu_item_parent', '0'),
(47, 31, '_menu_item_object_id', '27'),
(48, 31, '_menu_item_object', 'page'),
(49, 31, '_menu_item_target', ''),
(50, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(51, 31, '_menu_item_xfn', ''),
(52, 31, '_menu_item_url', ''),
(53, 31, '_menu_item_orphaned', '1692502177'),
(54, 32, '_menu_item_type', 'post_type'),
(55, 32, '_menu_item_menu_item_parent', '0'),
(56, 32, '_menu_item_object_id', '18'),
(57, 32, '_menu_item_object', 'page'),
(58, 32, '_menu_item_target', ''),
(59, 32, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(60, 32, '_menu_item_xfn', ''),
(61, 32, '_menu_item_url', ''),
(63, 33, '_menu_item_type', 'post_type'),
(64, 33, '_menu_item_menu_item_parent', '0'),
(65, 33, '_menu_item_object_id', '23'),
(66, 33, '_menu_item_object', 'page'),
(67, 33, '_menu_item_target', ''),
(68, 33, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(69, 33, '_menu_item_xfn', ''),
(70, 33, '_menu_item_url', ''),
(71, 33, '_menu_item_orphaned', '1692502177'),
(72, 34, '_menu_item_type', 'post_type'),
(73, 34, '_menu_item_menu_item_parent', '0'),
(74, 34, '_menu_item_object_id', '25'),
(75, 34, '_menu_item_object', 'page'),
(76, 34, '_menu_item_target', ''),
(77, 34, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(78, 34, '_menu_item_xfn', ''),
(79, 34, '_menu_item_url', ''),
(80, 34, '_menu_item_orphaned', '1692502177'),
(81, 35, '_menu_item_type', 'post_type'),
(82, 35, '_menu_item_menu_item_parent', '0'),
(83, 35, '_menu_item_object_id', '2'),
(84, 35, '_menu_item_object', 'page'),
(85, 35, '_menu_item_target', ''),
(86, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(87, 35, '_menu_item_xfn', ''),
(88, 35, '_menu_item_url', ''),
(89, 35, '_menu_item_orphaned', '1692502178'),
(90, 36, '_menu_item_type', 'post_type'),
(91, 36, '_menu_item_menu_item_parent', '0'),
(92, 36, '_menu_item_object_id', '11'),
(93, 36, '_menu_item_object', 'page'),
(94, 36, '_menu_item_target', ''),
(95, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(96, 36, '_menu_item_xfn', ''),
(97, 36, '_menu_item_url', ''),
(98, 36, '_menu_item_orphaned', '1692502178'),
(99, 37, '_menu_item_type', 'post_type'),
(100, 37, '_menu_item_menu_item_parent', '0'),
(101, 37, '_menu_item_object_id', '2'),
(102, 37, '_menu_item_object', 'page'),
(103, 37, '_menu_item_target', ''),
(104, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(105, 37, '_menu_item_xfn', ''),
(106, 37, '_menu_item_url', ''),
(108, 38, '_menu_item_type', 'post_type'),
(109, 38, '_menu_item_menu_item_parent', '0'),
(110, 38, '_menu_item_object_id', '27'),
(111, 38, '_menu_item_object', 'page') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(112, 38, '_menu_item_target', ''),
(113, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(114, 38, '_menu_item_xfn', ''),
(115, 38, '_menu_item_url', ''),
(117, 39, '_menu_item_type', 'post_type'),
(118, 39, '_menu_item_menu_item_parent', '0'),
(119, 39, '_menu_item_object_id', '18'),
(120, 39, '_menu_item_object', 'page'),
(121, 39, '_menu_item_target', ''),
(122, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(123, 39, '_menu_item_xfn', ''),
(124, 39, '_menu_item_url', ''),
(126, 40, '_menu_item_type', 'post_type'),
(127, 40, '_menu_item_menu_item_parent', '0'),
(128, 40, '_menu_item_object_id', '11'),
(129, 40, '_menu_item_object', 'page'),
(130, 40, '_menu_item_target', ''),
(131, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(132, 40, '_menu_item_xfn', ''),
(133, 40, '_menu_item_url', ''),
(135, 41, '_edit_lock', '1692575026:1'),
(136, 43, '_edit_lock', '1692575040:1'),
(137, 45, '_edit_lock', '1693672521:1'),
(142, 48, '_edit_last', '1'),
(143, 48, '_edit_lock', '1692816015:1'),
(144, 49, '_edit_last', '1'),
(145, 49, '_edit_lock', '1693884905:1'),
(146, 50, '_edit_last', '1'),
(147, 50, '_edit_lock', '1693884895:1'),
(148, 52, '_edit_last', '1'),
(149, 52, '_edit_lock', '1692843226:1'),
(152, 55, '_edit_last', '1'),
(153, 55, '_edit_lock', '1692848497:1'),
(154, 50, 'event_date', '20230825'),
(155, 50, '_event_date', 'field_64e6d14b5dfdd'),
(156, 49, 'event_date', '20230901'),
(157, 49, '_event_date', 'field_64e6d14b5dfdd'),
(158, 58, '_edit_lock', '1693885027:1'),
(159, 58, '_edit_last', '1'),
(160, 58, 'event_date', '20200723'),
(161, 58, '_event_date', 'field_64e6d14b5dfdd'),
(162, 59, '_edit_lock', '1693884868:1'),
(163, 59, '_edit_last', '1'),
(164, 59, 'event_date', '20231031'),
(165, 59, '_event_date', 'field_64e6d14b5dfdd'),
(166, 60, '_edit_lock', '1692901286:1'),
(167, 62, '_edit_lock', '1692916486:1'),
(168, 62, '_edit_last', '1'),
(169, 62, 'event_date', '20221231'),
(170, 62, '_event_date', 'field_64e6d14b5dfdd'),
(171, 63, '_edit_lock', '1692915955:1'),
(172, 64, '_edit_lock', '1693884843:1'),
(173, 65, '_edit_lock', '1693978366:1'),
(174, 66, '_edit_last', '1'),
(175, 66, '_edit_lock', '1693022770:1'),
(176, 59, 'related_programs', 'a:2:{i:0;s:2:"64";i:1;s:2:"63";}'),
(177, 59, '_related_programs', 'field_64e7dd20a1850'),
(178, 50, 'related_programs', 'a:1:{i:0;s:2:"65";}'),
(179, 50, '_related_programs', 'field_64e7dd20a1850'),
(180, 68, '_edit_lock', '1694461876:1'),
(181, 69, '_edit_lock', '1694234376:1'),
(182, 68, '_edit_last', '1'),
(183, 68, 'related_programs', 'a:2:{i:0;s:2:"63";i:1;s:2:"65";}'),
(184, 68, '_related_programs', 'field_64e7dd20a1850'),
(185, 70, '_wp_attached_file', '2023/08/my_profile_pic.jpg'),
(186, 70, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:400;s:6:"height";i:400;s:4:"file";s:26:"2023/08/my_profile_pic.jpg";s:8:"filesize";i:20318;s:5:"sizes";a:3:{s:19:"instructorLandscape";a:5:{s:4:"file";s:26:"my_profile_pic-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13280;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"my_profile_pic-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4759;}s:6:"medium";a:5:{s:4:"file";s:26:"my_profile_pic-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11599;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:15:"micSelectedArea";a:1:{s:9:"thumbnail";a:5:{s:1:"x";s:2:"32";s:1:"y";s:2:"66";s:1:"w";s:3:"284";s:1:"h";s:3:"284";s:5:"scale";s:15:"1.1428571428571";}}}'),
(187, 68, '_thumbnail_id', '70'),
(188, 69, '_edit_last', '1'),
(189, 69, 'related_programs', 'a:1:{i:0;s:2:"64";}'),
(190, 69, '_related_programs', 'field_64e7dd20a1850'),
(194, 72, '_wp_attached_file', '2023/08/my-professional-pic.png'),
(195, 72, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:399;s:6:"height";i:531;s:4:"file";s:31:"2023/08/my-professional-pic.png";s:8:"filesize";i:260379;s:5:"sizes";a:3:{s:19:"instructorLandscape";a:5:{s:4:"file";s:31:"my-professional-pic-399x260.png";s:5:"width";i:399;s:6:"height";i:260;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:103089;}s:9:"thumbnail";a:5:{s:4:"file";s:31:"my-professional-pic-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:31443;}s:6:"medium";a:5:{s:4:"file";s:31:"my-professional-pic-225x300.png";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:86097;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(196, 69, '_thumbnail_id', '72'),
(197, 73, '_edit_last', '1'),
(198, 73, '_edit_lock', '1693026832:1'),
(199, 76, '_wp_attached_file', '2023/08/cover-image.png'),
(200, 76, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1600;s:6:"height";i:609;s:4:"file";s:23:"2023/08/cover-image.png";s:8:"filesize";i:411613;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:23:"cover-image-300x114.png";s:5:"width";i:300;s:6:"height";i:114;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:29142;}s:5:"large";a:5:{s:4:"file";s:24:"cover-image-1024x390.png";s:5:"width";i:1024;s:6:"height";i:390;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:197089;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"cover-image-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:11910;}s:12:"medium_large";a:5:{s:4:"file";s:23:"cover-image-768x292.png";s:5:"width";i:768;s:6:"height";i:292;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:109141;}s:9:"1536x1536";a:5:{s:4:"file";s:24:"cover-image-1536x585.png";s:5:"width";i:1536;s:6:"height";i:585;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:477210;}s:19:"instructorLandscape";a:5:{s:4:"file";s:23:"cover-image-400x260.png";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:54896;}s:18:"instructorPortrait";a:5:{s:4:"file";s:23:"cover-image-480x609.png";s:5:"width";i:480;s:6:"height";i:609;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:118494;}s:10:"pageBanner";a:5:{s:4:"file";s:24:"cover-image-1500x350.png";s:5:"width";i:1500;s:6:"height";i:350;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:271352;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(201, 68, 'page_banner_subtitle', 'the leading voice on Data structures and Algorithms'),
(202, 68, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(203, 68, 'page_banner_background_image', '76'),
(204, 68, '_page_banner_background_image', 'field_64e98a5293f12'),
(207, 18, '_edit_last', '1'),
(208, 18, 'page_banner_subtitle', 'I am here to share my knowledge and learnings with others. 📚'),
(209, 18, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(210, 18, 'page_banner_background_image', '79'),
(211, 18, '_page_banner_background_image', 'field_64e98a5293f12'),
(212, 78, 'page_banner_subtitle', 'I am here to share my knowledge and learnings with others. 📚'),
(213, 78, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(214, 78, 'page_banner_background_image', '77'),
(215, 78, '_page_banner_background_image', 'field_64e98a5293f12'),
(216, 79, '_wp_attached_file', '2023/08/knowledge-1.jpg'),
(217, 79, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1374;s:6:"height";i:2061;s:4:"file";s:23:"2023/08/knowledge-1.jpg";s:8:"filesize";i:366227;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:23:"knowledge-1-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10825;}s:5:"large";a:5:{s:4:"file";s:24:"knowledge-1-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:76499;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"knowledge-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5826;}s:12:"medium_large";a:5:{s:4:"file";s:24:"knowledge-1-768x1152.jpg";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:93451;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"knowledge-1-1024x1536.jpg";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:158167;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"knowledge-1-1365x2048.jpg";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:279112;}s:19:"instructorLandscape";a:5:{s:4:"file";s:23:"knowledge-1-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21308;}s:18:"instructorPortrait";a:5:{s:4:"file";s:23:"knowledge-1-480x650.jpg";s:5:"width";i:480;s:6:"height";i:650;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:41134;}s:10:"pageBanner";a:5:{s:4:"file";s:24:"knowledge-1-1374x350.jpg";s:5:"width";i:1374;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:93499;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(218, 80, 'page_banner_subtitle', 'I am here to share my knowledge and learnings with others. 📚'),
(219, 80, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(220, 80, 'page_banner_background_image', '79'),
(221, 80, '_page_banner_background_image', 'field_64e98a5293f12'),
(222, 49, 'page_banner_subtitle', 'All about Data Structures & Algorithms '),
(223, 49, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(224, 49, 'page_banner_background_image', '81'),
(225, 49, '_page_banner_background_image', 'field_64e98a5293f12') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(226, 49, 'related_programs', 'a:1:{i:0;s:2:"63";}'),
(227, 49, '_related_programs', 'field_64e7dd20a1850'),
(228, 81, '_wp_attached_file', '2023/08/events.jpg'),
(229, 81, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1374;s:6:"height";i:1031;s:4:"file";s:18:"2023/08/events.jpg";s:8:"filesize";i:101884;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:18:"events-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7546;}s:5:"large";a:5:{s:4:"file";s:19:"events-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:53687;}s:9:"thumbnail";a:5:{s:4:"file";s:18:"events-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3693;}s:12:"medium_large";a:5:{s:4:"file";s:18:"events-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:34036;}s:19:"instructorLandscape";a:5:{s:4:"file";s:18:"events-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11458;}s:18:"instructorPortrait";a:5:{s:4:"file";s:18:"events-480x650.jpg";s:5:"width";i:480;s:6:"height";i:650;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:32417;}s:10:"pageBanner";a:5:{s:4:"file";s:19:"events-1374x350.jpg";s:5:"width";i:1374;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:48809;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(230, 82, '_edit_lock', '1693285917:1'),
(231, 82, '_edit_last', '1'),
(232, 82, 'page_banner_subtitle', ''),
(233, 82, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(234, 82, 'page_banner_background_image', ''),
(235, 82, '_page_banner_background_image', 'field_64e98a5293f12'),
(236, 83, '_edit_lock', '1693284411:1'),
(237, 83, '_edit_last', '1'),
(238, 83, 'page_banner_subtitle', ''),
(239, 83, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(240, 83, 'page_banner_background_image', ''),
(241, 83, '_page_banner_background_image', 'field_64e98a5293f12'),
(242, 86, '_edit_last', '1'),
(243, 86, '_edit_lock', '1693284081:1'),
(244, 82, 'map_location', '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d46186.90251497907!2d-79.45298767754369!3d43.654796403066854!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d4cb34d27310bd%3A0xba15d20622070393!2sDowntown%20Toronto%2C%20Toronto%2C%20ON!5e0!3m2!1sen!2sca!4v1693279211364!5m2!1sen!2sca" width="1000" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>'),
(245, 82, '_map_location', 'field_64ed5d30ea9b6'),
(246, 83, 'map_location', '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d24199.91997193826!2d-74.02206385050876!3d40.696217961801274!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a4a8a2a0203%3A0xdff417da15980851!2sDowntown%20Brooklyn%2C%20Brooklyn%2C%20NY%2C%20USA!5e0!3m2!1sen!2sca!4v1693284355699!5m2!1sen!2sca" width="1000" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>'),
(247, 83, '_map_location', 'field_64ed5d30ea9b6'),
(248, 89, '_edit_last', '1'),
(249, 89, '_edit_lock', '1693285946:1'),
(250, 65, '_edit_last', '1'),
(251, 65, 'page_banner_subtitle', ''),
(252, 65, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(253, 65, 'page_banner_background_image', ''),
(254, 65, '_page_banner_background_image', 'field_64e98a5293f12'),
(255, 65, 'related_campus', 'a:1:{i:0;s:2:"82";}'),
(256, 65, '_related_campus', 'field_64ed7e28c5486'),
(257, 64, '_edit_last', '1'),
(258, 64, 'page_banner_subtitle', ''),
(259, 64, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(260, 64, 'page_banner_background_image', ''),
(261, 64, '_page_banner_background_image', 'field_64e98a5293f12'),
(262, 64, 'related_campus', 'a:1:{i:0;s:2:"82";}'),
(263, 64, '_related_campus', 'field_64ed7e28c5486'),
(264, 91, '_edit_lock', '1694570798:1'),
(267, 91, '_edit_last', '1'),
(269, 91, 'page_banner_subtitle', ''),
(270, 91, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(271, 91, 'page_banner_background_image', ''),
(272, 91, '_page_banner_background_image', 'field_64e98a5293f12'),
(273, 92, 'page_banner_subtitle', ''),
(274, 92, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(275, 92, 'page_banner_background_image', ''),
(276, 92, '_page_banner_background_image', 'field_64e98a5293f12'),
(279, 45, '_edit_last', '1'),
(280, 45, '_pingme', '1'),
(281, 45, '_encloseme', '1'),
(282, 45, 'page_banner_subtitle', ''),
(283, 45, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(284, 45, 'page_banner_background_image', ''),
(285, 45, '_page_banner_background_image', 'field_64e98a5293f12'),
(286, 93, 'page_banner_subtitle', ''),
(287, 93, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(288, 93, 'page_banner_background_image', ''),
(289, 93, '_page_banner_background_image', 'field_64e98a5293f12'),
(290, 94, '_edit_last', '1'),
(291, 94, '_edit_lock', '1693675209:1'),
(292, 64, 'main_body_content', 'Just like frontend, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(293, 64, '_main_body_content', 'field_64f36ed1ce4b6'),
(294, 64, '_', 'field_64f36ed8ce4b7'),
(295, 58, 'page_banner_subtitle', ''),
(296, 58, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(297, 58, 'page_banner_background_image', ''),
(298, 58, '_page_banner_background_image', 'field_64e98a5293f12'),
(299, 58, 'related_programs', 'a:1:{i:0;s:2:"64";}'),
(300, 58, '_related_programs', 'field_64e7dd20a1850'),
(301, 97, '_edit_lock', '1693979609:1'),
(302, 97, '_edit_last', '1'),
(303, 97, 'page_banner_subtitle', ''),
(304, 97, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(305, 97, 'page_banner_background_image', ''),
(306, 97, '_page_banner_background_image', 'field_64e98a5293f12'),
(307, 98, 'page_banner_subtitle', ''),
(308, 98, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(309, 98, 'page_banner_background_image', ''),
(310, 98, '_page_banner_background_image', 'field_64e98a5293f12'),
(311, 99, '_edit_lock', '1694022610:1'),
(312, 101, '_edit_lock', '1694023743:2'),
(313, 101, '_edit_last', '2'),
(314, 101, 'event_date', '20230922'),
(315, 101, '_event_date', 'field_64e6d14b5dfdd'),
(316, 101, 'page_banner_subtitle', ''),
(317, 101, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(318, 101, 'page_banner_background_image', ''),
(319, 101, '_page_banner_background_image', 'field_64e98a5293f12'),
(320, 101, 'related_programs', 'a:1:{i:0;s:2:"63";}'),
(321, 101, '_related_programs', 'field_64e7dd20a1850'),
(322, 102, '_edit_lock', '1694056222:1'),
(323, 102, '_edit_last', '1'),
(324, 102, 'page_banner_subtitle', ''),
(325, 102, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(326, 102, 'page_banner_background_image', ''),
(327, 102, '_page_banner_background_image', 'field_64e98a5293f12'),
(328, 103, 'page_banner_subtitle', ''),
(329, 103, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(330, 103, 'page_banner_background_image', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(331, 103, '_page_banner_background_image', 'field_64e98a5293f12'),
(332, 104, '_edit_lock', '1694057927:1'),
(333, 104, '_edit_last', '1'),
(334, 104, 'page_banner_subtitle', ''),
(335, 104, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(336, 104, 'page_banner_background_image', ''),
(337, 104, '_page_banner_background_image', 'field_64e98a5293f12'),
(338, 105, '_edit_lock', '1694107145:1'),
(339, 105, '_edit_last', '1'),
(340, 105, 'page_banner_subtitle', ''),
(341, 105, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(342, 105, 'page_banner_background_image', ''),
(343, 105, '_page_banner_background_image', 'field_64e98a5293f12'),
(347, 106, '_edit_lock', '1694057647:1'),
(351, 107, '_edit_lock', '1694107105:1'),
(352, 107, '_edit_last', '1'),
(353, 107, 'page_banner_subtitle', ''),
(354, 107, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(355, 107, 'page_banner_background_image', ''),
(356, 107, '_page_banner_background_image', 'field_64e98a5293f12'),
(357, 107, '_wp_trash_meta_status', 'publish'),
(358, 107, '_wp_trash_meta_time', '1694145167'),
(359, 107, '_wp_desired_post_slug', 'javascript-lecture-4'),
(360, 108, '_edit_last', '1'),
(361, 108, '_edit_lock', '1694150535:1'),
(362, 108, 'page_banner_subtitle', ''),
(363, 108, '_page_banner_subtitle', 'field_64e98a3e93f11'),
(364, 108, 'page_banner_background_image', ''),
(365, 108, '_page_banner_background_image', 'field_64e98a5293f12'),
(366, 109, '_wp_trash_meta_status', 'private'),
(367, 109, '_wp_trash_meta_time', '1694153377'),
(368, 109, '_wp_desired_post_slug', 'sklfnkos'),
(369, 110, '_wp_trash_meta_status', 'private'),
(370, 110, '_wp_trash_meta_time', '1694153466'),
(371, 110, '_wp_desired_post_slug', '110'),
(372, 111, '_wp_trash_meta_status', 'private'),
(373, 111, '_wp_trash_meta_time', '1694153831'),
(374, 111, '_wp_desired_post_slug', 'subscriber-html'),
(375, 112, '_wp_trash_meta_status', 'private'),
(376, 112, '_wp_trash_meta_time', '1694153982'),
(377, 112, '_wp_desired_post_slug', '112'),
(378, 113, '_wp_trash_meta_status', 'private'),
(379, 113, '_wp_trash_meta_time', '1694154301'),
(380, 113, '_wp_desired_post_slug', 'sdrfgdrs'),
(381, 114, '_wp_trash_meta_status', 'private'),
(382, 114, '_wp_trash_meta_time', '1694154302'),
(383, 114, '_wp_desired_post_slug', 'dshbsdf'),
(384, 115, '_wp_trash_meta_status', 'private'),
(385, 115, '_wp_trash_meta_time', '1694154303'),
(386, 115, '_wp_desired_post_slug', 'dsfghdf'),
(387, 116, '_wp_trash_meta_status', 'private'),
(388, 116, '_wp_trash_meta_time', '1694154329'),
(389, 116, '_wp_desired_post_slug', 'sdgfhsdfh'),
(390, 117, '_wp_trash_meta_status', 'private'),
(391, 117, '_wp_trash_meta_time', '1694154331'),
(392, 117, '_wp_desired_post_slug', 'safgs'),
(393, 118, '_wp_trash_meta_status', 'private'),
(394, 118, '_wp_trash_meta_time', '1694154333'),
(395, 118, '_wp_desired_post_slug', 'agaegeasd'),
(396, 121, '_wp_trash_meta_status', 'private'),
(397, 121, '_wp_trash_meta_time', '1694154429'),
(398, 121, '_wp_desired_post_slug', 'wfwef'),
(399, 122, '_wp_trash_meta_status', 'private'),
(400, 122, '_wp_trash_meta_time', '1694154430'),
(401, 122, '_wp_desired_post_slug', 'pp'),
(402, 120, '_wp_trash_meta_status', 'private'),
(403, 120, '_wp_trash_meta_time', '1694154431'),
(404, 120, '_wp_desired_post_slug', 'wef'),
(405, 119, '_wp_trash_meta_status', 'private'),
(406, 119, '_wp_trash_meta_time', '1694154712'),
(407, 119, '_wp_desired_post_slug', 'qafdqw'),
(408, 119, '_wp_trash_meta_status', 'private'),
(409, 119, '_wp_trash_meta_time', '1694154733'),
(410, 123, '_wp_trash_meta_status', 'private'),
(411, 123, '_wp_trash_meta_time', '1694154734'),
(412, 123, '_wp_desired_post_slug', 'safsd'),
(413, 124, '_wp_trash_meta_status', 'private'),
(414, 124, '_wp_trash_meta_time', '1694154736'),
(415, 124, '_wp_desired_post_slug', 'sdfsa'),
(416, 124, '_wp_trash_meta_status', 'private'),
(417, 124, '_wp_trash_meta_time', '1694154742'),
(418, 123, '_wp_trash_meta_status', 'private'),
(419, 123, '_wp_trash_meta_time', '1694154743'),
(420, 119, '_wp_trash_meta_status', 'private'),
(421, 119, '_wp_trash_meta_time', '1694154744'),
(422, 119, '_wp_trash_meta_status', 'private'),
(423, 119, '_wp_trash_meta_time', '1694154750'),
(424, 123, '_wp_trash_meta_status', 'private'),
(425, 123, '_wp_trash_meta_time', '1694154752'),
(426, 124, '_wp_trash_meta_status', 'private'),
(427, 124, '_wp_trash_meta_time', '1694154753'),
(428, 124, '_wp_trash_meta_status', 'private'),
(429, 124, '_wp_trash_meta_time', '1694154981'),
(430, 123, '_wp_trash_meta_status', 'private'),
(431, 123, '_wp_trash_meta_time', '1694154982'),
(432, 119, '_wp_trash_meta_status', 'private'),
(433, 119, '_wp_trash_meta_time', '1694154983'),
(434, 127, '_wp_trash_meta_status', 'private'),
(435, 127, '_wp_trash_meta_time', '1694155041'),
(436, 127, '_wp_desired_post_slug', 'third') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(437, 126, '_wp_trash_meta_status', 'private'),
(438, 126, '_wp_trash_meta_time', '1694155042'),
(439, 126, '_wp_desired_post_slug', 'second'),
(440, 128, '_wp_trash_meta_status', 'private'),
(441, 128, '_wp_trash_meta_time', '1694155062'),
(442, 128, '_wp_desired_post_slug', 'fifth'),
(443, 130, '_wp_trash_meta_status', 'private'),
(444, 130, '_wp_trash_meta_time', '1694155143'),
(445, 130, '_wp_desired_post_slug', 'third'),
(446, 131, '_wp_trash_meta_status', 'private'),
(447, 131, '_wp_trash_meta_time', '1694155323'),
(448, 131, '_wp_desired_post_slug', 'asda'),
(449, 129, '_wp_trash_meta_status', 'private'),
(450, 129, '_wp_trash_meta_time', '1694155324'),
(451, 129, '_wp_desired_post_slug', 'second'),
(452, 125, '_wp_trash_meta_status', 'private'),
(453, 125, '_wp_trash_meta_time', '1694155326'),
(454, 125, '_wp_desired_post_slug', 'first'),
(455, 134, '_wp_trash_meta_status', 'private'),
(456, 134, '_wp_trash_meta_time', '1694155677'),
(457, 134, '_wp_desired_post_slug', 'wefweq'),
(458, 135, '_wp_trash_meta_status', 'private'),
(459, 135, '_wp_trash_meta_time', '1694156669'),
(460, 135, '_wp_desired_post_slug', 'erger'),
(461, 136, '_wp_trash_meta_status', 'private'),
(462, 136, '_wp_trash_meta_time', '1694156677'),
(463, 136, '_wp_desired_post_slug', 'ylkiutyl'),
(464, 137, '_wp_trash_meta_status', 'private'),
(465, 137, '_wp_trash_meta_time', '1694156681'),
(466, 137, '_wp_desired_post_slug', '137'),
(467, 141, '_edit_lock', '1694233434:1'),
(468, 142, '_edit_lock', '1694234206:1'),
(469, 142, '_edit_last', '1'),
(470, 145, '_edit_lock', '1694233558:1'),
(547, 166, '_edit_lock', '1694543875:1'),
(548, 167, '_edit_lock', '1694562535:1'),
(549, 167, '_edit_last', '1'),
(733, 218, 'liked_post_id', '45'),
(734, 218, '_edit_lock', '1694565783:1'),
(754, 234, 'liked_instructor_id', '68') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=235 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2023-08-19 17:17:20', '2023-08-19 17:17:20', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2023-08-19 17:17:20', '2023-08-19 17:17:20', '', 0, 'http://bytebookexchange.com?p=1', 0, 'post', '', 1),
(2, 1, '2023-08-19 17:17:20', '2023-08-19 17:17:20', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://bytebookexchange.comwp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2023-08-19 17:17:20', '2023-08-19 17:17:20', '', 0, 'http://bytebookexchange.com?page_id=2', 0, 'page', '', 0),
(3, 1, '2023-08-19 17:17:20', '2023-08-19 17:17:20', '<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we are</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://bytebookexchange.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Comments</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor’s IP address and browser user agent string to help spam detection.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Media</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Cookies</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select "Remember Me", your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Embedded content from other websites</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we share your data with</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">How long we retain your data</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">What rights you have over your data</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Where your data is sent</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p>\n<!-- /wp:paragraph -->', 'Privacy Policy', '', 'publish', 'closed', 'open', '', 'privacy-policy', '', '', '2023-08-19 23:19:37', '2023-08-19 23:19:37', '', 0, 'http://bytebookexchange.com?page_id=3', 0, 'page', '', 0),
(4, 0, '2023-08-19 17:17:29', '2023-08-19 17:17:29', '<!-- wp:page-list /-->', 'Navigation', '', 'publish', 'closed', 'closed', '', 'navigation', '', '', '2023-08-19 17:17:29', '2023-08-19 17:17:29', '', 0, 'https://bytebookexchange.comnavigation/', 0, 'wp_navigation', '', 0),
(7, 1, '2023-08-19 18:38:13', '2023-08-19 18:38:13', '<!-- wp:paragraph -->\n<p>Yes, this is a test post here buddy........so keep on looking :)Yes, this is a test post here buddy........so keep on looking :)Yes, this is a test post here buddy........so keep on looking :)Yes, this is a test post here buddy........so keep on looking :)Yes, this is a test post here buddy........so keep on looking :)Yes, this is a test post here buddy........so keep on looking :)Yes, this is a test post here buddy........so keep on looking :)Yes, this is a test post here buddy........so keep on looking :)</p>\n<!-- /wp:paragraph -->', 'Test Post', '', 'publish', 'open', 'open', '', 'test-post', '', '', '2023-08-19 18:38:13', '2023-08-19 18:38:13', '', 0, 'http://bytebookexchange.com?p=7', 0, 'post', '', 0),
(8, 1, '2023-08-19 18:38:13', '2023-08-19 18:38:13', '<!-- wp:paragraph -->\n<p>Yes, this is a test post here buddy........so keep on looking :)Yes, this is a test post here buddy........so keep on looking :)Yes, this is a test post here buddy........so keep on looking :)Yes, this is a test post here buddy........so keep on looking :)Yes, this is a test post here buddy........so keep on looking :)Yes, this is a test post here buddy........so keep on looking :)Yes, this is a test post here buddy........so keep on looking :)Yes, this is a test post here buddy........so keep on looking :)</p>\n<!-- /wp:paragraph -->', 'Test Post', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2023-08-19 18:38:13', '2023-08-19 18:38:13', '', 7, 'http://bytebookexchange.com?p=8', 0, 'revision', '', 0),
(9, 1, '2023-08-19 18:38:55', '2023-08-19 18:38:55', '<!-- wp:paragraph -->\n<p>Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....</p>\n<!-- /wp:paragraph -->', 'Second Dummy Post', 'Our university has won another award this year.', 'publish', 'open', 'open', '', 'second-dummy-post', '', '', '2023-08-24 03:06:22', '2023-08-24 03:06:22', '', 0, 'http://bytebookexchange.com?p=9', 0, 'post', '', 0),
(10, 1, '2023-08-19 18:38:55', '2023-08-19 18:38:55', '<!-- wp:paragraph -->\n<p>Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....</p>\n<!-- /wp:paragraph -->', 'Second Dummy Post', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2023-08-19 18:38:55', '2023-08-19 18:38:55', '', 9, 'http://bytebookexchange.com?p=10', 0, 'revision', '', 0),
(11, 1, '2023-08-19 18:56:55', '2023-08-19 18:56:55', '<!-- wp:paragraph -->\n<p>Yoyoyoy this is the test page 1</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yoyoyoy this is the test page 1</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yoyoyoy this is the test page 1</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yoyoyoy this is the test page 1</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yoyoyoy this is the test page 1</p>\n<!-- /wp:paragraph -->', 'Test Page1', '', 'publish', 'closed', 'closed', '', 'test-page1', '', '', '2023-08-19 18:56:55', '2023-08-19 18:56:55', '', 0, 'http://bytebookexchange.com?page_id=11', 0, 'page', '', 0),
(12, 1, '2023-08-19 18:56:55', '2023-08-19 18:56:55', '<!-- wp:paragraph -->\n<p>Yoyoyoy this is the test page 1</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yoyoyoy this is the test page 1</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yoyoyoy this is the test page 1</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yoyoyoy this is the test page 1</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yoyoyoy this is the test page 1</p>\n<!-- /wp:paragraph -->', 'Test Page1', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2023-08-19 18:56:55', '2023-08-19 18:56:55', '', 11, 'http://bytebookexchange.com?p=12', 0, 'revision', '', 0),
(14, 1, '2023-08-19 23:17:48', '2023-08-19 23:17:48', '', 'IO', '', 'trash', 'closed', 'closed', '', '__trashed', '', '', '2023-08-19 23:17:48', '2023-08-19 23:17:48', '', 0, 'http://bytebookexchange.com?page_id=14', 0, 'page', '', 0),
(15, 1, '2023-08-19 23:17:48', '2023-08-19 23:17:48', '<!-- wp:paragraph -->\n<p>Lorem lorem isum iposum is the fil;e </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem lorem isum iposum is the fil;e </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem lorem isum iposum is the fil;e </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem lorem isum iposum is the fil;e </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem lorem isum iposum is the fil;e </p>\n<!-- /wp:paragraph -->', 'Our History', '', 'trash', 'closed', 'closed', '', '__trashed-2', '', '', '2023-08-19 23:17:48', '2023-08-19 23:17:48', '', 0, 'http://bytebookexchange.com?page_id=15', 0, 'page', '', 0),
(16, 1, '2023-08-19 23:17:48', '2023-08-19 23:17:48', '', 'IO', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2023-08-19 23:17:48', '2023-08-19 23:17:48', '', 14, 'http://bytebookexchange.com?p=16', 0, 'revision', '', 0),
(17, 1, '2023-08-19 23:17:48', '2023-08-19 23:17:48', '<!-- wp:paragraph -->\n<p>Lorem lorem isum iposum is the fil;e </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem lorem isum iposum is the fil;e </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem lorem isum iposum is the fil;e </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem lorem isum iposum is the fil;e </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem lorem isum iposum is the fil;e </p>\n<!-- /wp:paragraph -->', 'Our History', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2023-08-19 23:17:48', '2023-08-19 23:17:48', '', 15, 'http://bytebookexchange.com?p=17', 0, 'revision', '', 0),
(18, 1, '2023-08-19 23:19:16', '2023-08-19 23:19:16', '<!-- wp:paragraph -->\n<p>This is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsum</p>\n<!-- /wp:paragraph -->', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2023-08-26 16:52:29', '2023-08-26 16:52:29', '', 0, 'http://bytebookexchange.com?page_id=18', 0, 'page', '', 0),
(19, 1, '2023-08-19 23:19:16', '2023-08-19 23:19:16', '<!-- wp:paragraph -->\n<p>This is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsum</p>\n<!-- /wp:paragraph -->', 'About Us', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2023-08-19 23:19:16', '2023-08-19 23:19:16', '', 18, 'http://bytebookexchange.com?p=19', 0, 'revision', '', 0),
(20, 1, '2023-08-19 23:19:37', '2023-08-19 23:19:37', '<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we are</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://bytebookexchange.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Comments</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor’s IP address and browser user agent string to help spam detection.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Media</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Cookies</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select "Remember Me", your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Embedded content from other websites</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we share your data with</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">How long we retain your data</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">What rights you have over your data</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Where your data is sent</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p>\n<!-- /wp:paragraph -->', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2023-08-19 23:19:37', '2023-08-19 23:19:37', '', 3, 'http://bytebookexchange.com?p=20', 0, 'revision', '', 0),
(23, 1, '2023-08-20 00:50:52', '2023-08-20 00:50:52', '<!-- wp:paragraph -->\n<p>Yoyoyoyo this is the history of us yes about us history of us ;)</p>\n<!-- /wp:paragraph -->', 'Our History', '', 'publish', 'closed', 'closed', '', 'our-history', '', '', '2023-08-20 02:39:05', '2023-08-20 02:39:05', '', 18, 'http://bytebookexchange.com?page_id=23', 1, 'page', '', 0),
(24, 1, '2023-08-20 00:50:52', '2023-08-20 00:50:52', '<!-- wp:paragraph -->\n<p>Yoyoyoyo this is the history of us yes about us history of us ;)</p>\n<!-- /wp:paragraph -->', 'Our History', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2023-08-20 00:50:52', '2023-08-20 00:50:52', '', 23, 'http://bytebookexchange.com?p=24', 0, 'revision', '', 0),
(25, 1, '2023-08-20 00:51:38', '2023-08-20 00:51:38', '<!-- wp:paragraph -->\n<p>Yo these are our goals at the moment buddy.Yo these are our goals at the moment buddy.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yo these are our goals at the moment buddy.Yo these are our goals at the moment buddy.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yo these are our goals at the moment buddy.Yo these are our goals at the moment buddy.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yo these are our goals at the moment buddy.Yo these are our goals at the moment buddy.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yo these are our goals at the moment buddy.Yo these are our goals at the moment buddy.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yo these are our goals at the moment buddy.Yo these are our goals at the moment buddy.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yo these are our goals at the moment buddy.Yo these are our goals at the moment buddy.</p>\n<!-- /wp:paragraph -->', 'Our Goals', '', 'publish', 'closed', 'closed', '', 'our-goals', '', '', '2023-08-20 02:39:22', '2023-08-20 02:39:22', '', 18, 'http://bytebookexchange.com?page_id=25', 2, 'page', '', 0),
(26, 1, '2023-08-20 00:51:38', '2023-08-20 00:51:38', '<!-- wp:paragraph -->\n<p>Yo these are our goals at the moment buddy.Yo these are our goals at the moment buddy.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yo these are our goals at the moment buddy.Yo these are our goals at the moment buddy.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yo these are our goals at the moment buddy.Yo these are our goals at the moment buddy.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yo these are our goals at the moment buddy.Yo these are our goals at the moment buddy.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yo these are our goals at the moment buddy.Yo these are our goals at the moment buddy.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yo these are our goals at the moment buddy.Yo these are our goals at the moment buddy.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yo these are our goals at the moment buddy.Yo these are our goals at the moment buddy.</p>\n<!-- /wp:paragraph -->', 'Our Goals', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2023-08-20 00:51:38', '2023-08-20 00:51:38', '', 25, 'http://bytebookexchange.com?p=26', 0, 'revision', '', 0),
(27, 1, '2023-08-20 02:00:11', '2023-08-20 02:00:11', '<!-- wp:paragraph -->\n<p>So there are the cookies policies which you need to eat before entering into this website..</p>\n<!-- /wp:paragraph -->', 'Cookie Policy', '', 'publish', 'closed', 'closed', '', 'cookie-policy', '', '', '2023-08-20 02:00:11', '2023-08-20 02:00:11', '', 3, 'http://bytebookexchange.com?page_id=27', 0, 'page', '', 0),
(28, 1, '2023-08-20 02:00:11', '2023-08-20 02:00:11', '<!-- wp:paragraph -->\n<p>So there are the cookies policies which you need to eat before entering into this website..</p>\n<!-- /wp:paragraph -->', 'Cookie Policy', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2023-08-20 02:00:11', '2023-08-20 02:00:11', '', 27, 'http://bytebookexchange.com?p=28', 0, 'revision', '', 0),
(29, 1, '2023-08-20 03:29:36', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-08-20 03:29:36', '0000-00-00 00:00:00', '', 0, 'http://bytebookexchange.com?p=29', 1, 'nav_menu_item', '', 0),
(30, 1, '2023-08-20 03:30:45', '2023-08-20 03:30:23', ' ', '', '', 'publish', 'closed', 'closed', '', '30', '', '', '2023-08-20 03:30:45', '2023-08-20 03:30:45', '', 0, 'http://bytebookexchange.com?p=30', 1, 'nav_menu_item', '', 0),
(31, 1, '2023-08-20 03:29:37', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-08-20 03:29:37', '0000-00-00 00:00:00', '', 3, 'http://bytebookexchange.com?p=31', 1, 'nav_menu_item', '', 0),
(32, 1, '2023-08-20 03:30:45', '2023-08-20 03:30:23', ' ', '', '', 'publish', 'closed', 'closed', '', '32', '', '', '2023-08-20 03:30:45', '2023-08-20 03:30:45', '', 0, 'http://bytebookexchange.com?p=32', 2, 'nav_menu_item', '', 0),
(33, 1, '2023-08-20 03:29:37', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-08-20 03:29:37', '0000-00-00 00:00:00', '', 18, 'http://bytebookexchange.com?p=33', 1, 'nav_menu_item', '', 0),
(34, 1, '2023-08-20 03:29:37', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-08-20 03:29:37', '0000-00-00 00:00:00', '', 18, 'http://bytebookexchange.com?p=34', 1, 'nav_menu_item', '', 0),
(35, 1, '2023-08-20 03:29:37', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-08-20 03:29:37', '0000-00-00 00:00:00', '', 0, 'http://bytebookexchange.com?p=35', 1, 'nav_menu_item', '', 0),
(36, 1, '2023-08-20 03:29:38', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-08-20 03:29:38', '0000-00-00 00:00:00', '', 0, 'http://bytebookexchange.com?p=36', 1, 'nav_menu_item', '', 0),
(37, 1, '2023-08-20 03:37:39', '2023-08-20 03:37:29', ' ', '', '', 'publish', 'closed', 'closed', '', '37', '', '', '2023-08-20 03:37:39', '2023-08-20 03:37:39', '', 0, 'http://bytebookexchange.com?p=37', 1, 'nav_menu_item', '', 0),
(38, 1, '2023-08-20 03:37:39', '2023-08-20 03:37:29', ' ', '', '', 'publish', 'closed', 'closed', '', '38', '', '', '2023-08-20 03:37:39', '2023-08-20 03:37:39', '', 3, 'http://bytebookexchange.com?p=38', 2, 'nav_menu_item', '', 0),
(39, 1, '2023-08-20 03:39:49', '2023-08-20 03:39:49', ' ', '', '', 'publish', 'closed', 'closed', '', '39', '', '', '2023-08-20 03:39:49', '2023-08-20 03:39:49', '', 0, 'http://bytebookexchange.com?p=39', 1, 'nav_menu_item', '', 0),
(40, 1, '2023-08-20 03:39:49', '2023-08-20 03:39:49', ' ', '', '', 'publish', 'closed', 'closed', '', '40', '', '', '2023-08-20 03:39:49', '2023-08-20 03:39:49', '', 0, 'http://bytebookexchange.com?p=40', 2, 'nav_menu_item', '', 0),
(41, 1, '2023-08-20 23:46:08', '2023-08-20 23:46:08', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2023-08-20 23:46:08', '2023-08-20 23:46:08', '', 0, 'http://bytebookexchange.com?page_id=41', 0, 'page', '', 0),
(42, 1, '2023-08-20 23:46:08', '2023-08-20 23:46:08', '', 'Home', '', 'inherit', 'closed', 'closed', '', '41-revision-v1', '', '', '2023-08-20 23:46:08', '2023-08-20 23:46:08', '', 41, 'http://bytebookexchange.com?p=42', 0, 'revision', '', 0),
(43, 1, '2023-08-20 23:46:23', '2023-08-20 23:46:23', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2023-08-20 23:46:23', '2023-08-20 23:46:23', '', 0, 'http://bytebookexchange.com?page_id=43', 0, 'page', '', 0),
(44, 1, '2023-08-20 23:46:23', '2023-08-20 23:46:23', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2023-08-20 23:46:23', '2023-08-20 23:46:23', '', 43, 'http://bytebookexchange.com?p=44', 0, 'revision', '', 0),
(45, 1, '2023-08-21 00:40:02', '2023-08-21 00:40:02', '<!-- wp:quote -->\n<blockquote class="wp-block-quote"><!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<!-- /wp:paragraph --></blockquote>\n<!-- /wp:quote -->', 'We Won an Award', '', 'publish', 'open', 'open', '', 'we-won-an-award', '', '', '2023-08-29 22:12:01', '2023-08-29 22:12:01', '', 0, 'http://bytebookexchange.com?p=45', 0, 'post', '', 0),
(46, 1, '2023-08-21 00:40:02', '2023-08-21 00:40:02', '<!-- wp:paragraph -->\n<p>Yes buddy, we have won a great award and very happy about it :D</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yes buddy, we have won a great award and very happy about it :D</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yes buddy, we have won a great award and very happy about it :D</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yes buddy, we have won a great award and very happy about it :D</p>\n<!-- /wp:paragraph -->', 'We Won an Award', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2023-08-21 00:40:02', '2023-08-21 00:40:02', '', 45, 'http://bytebookexchange.com?p=46', 0, 'revision', '', 0),
(48, 1, '2023-08-23 18:42:38', '2023-08-23 18:42:38', '', 'JavaScript Meetup', '', 'publish', 'closed', 'closed', '', 'javascript-meetup', '', '', '2023-08-23 18:42:38', '2023-08-23 18:42:38', '', 0, 'http://bytebookexchange.com?post_type=event&#038;p=48', 0, 'event', '', 0),
(49, 1, '2023-08-23 18:42:58', '2023-08-23 18:42:58', 'In this, I will cover data structures and algorithms from scratch. You will learn about Arrays, Strings, Trees and a lot more.', 'Data Structures & Algorithms', '', 'publish', 'closed', 'closed', '', 'data-structures-algorithms', '', '', '2023-08-27 18:49:43', '2023-08-27 18:49:43', '', 0, 'http://bytebookexchange.com?post_type=event&#038;p=49', 0, 'event', '', 0),
(50, 1, '2023-08-23 18:43:22', '2023-08-23 18:43:22', 'We are going to learn alot about how all the <strong>JavaScript</strong> frontend framework works and you will enjoy every step. I assure you that', 'Front-End Frameworks', 'The event will be highly focused on discussing popular front-end choices.', 'publish', 'closed', 'closed', '', 'front-end-frameworks', '', '', '2023-08-24 23:41:41', '2023-08-24 23:41:41', '', 0, 'http://bytebookexchange.com?post_type=event&#038;p=50', 0, 'event', '', 0),
(52, 1, '2023-08-24 02:15:15', '0000-00-00 00:00:00', '', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-08-24 02:15:15', '2023-08-24 02:15:15', '', 0, 'http://bytebookexchange.com?post_type=event&#038;p=52', 0, 'event', '', 0),
(54, 1, '2023-08-24 03:06:22', '2023-08-24 03:06:22', '<!-- wp:paragraph -->\n<p>Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....Yes, this is a second dummy post in the list here guys....</p>\n<!-- /wp:paragraph -->', 'Second Dummy Post', 'Our university has won another award this year.', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2023-08-24 03:06:22', '2023-08-24 03:06:22', '', 9, 'http://bytebookexchange.com?p=54', 0, 'revision', '', 0),
(55, 1, '2023-08-24 03:42:56', '2023-08-24 03:42:56', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"event";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Event Date', 'event-date', 'publish', 'closed', 'closed', '', 'group_64e6d138be052', '', '', '2023-08-24 03:43:54', '2023-08-24 03:43:54', '', 0, 'http://bytebookexchange.com?post_type=acf-field-group&#038;p=55', 0, 'acf-field-group', '', 0),
(57, 1, '2023-08-24 03:42:56', '2023-08-24 03:42:56', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:11:"date_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:14:"display_format";s:5:"d/m/Y";s:13:"return_format";s:3:"Ymd";s:9:"first_day";i:1;}', 'Event Date', 'event_date', 'publish', 'closed', 'closed', '', 'field_64e6d14b5dfdd', '', '', '2023-08-24 03:43:54', '2023-08-24 03:43:54', '', 55, 'http://bytebookexchange.com?post_type=acf-field&#038;p=57', 0, 'acf-field', '', 0),
(58, 1, '2023-08-24 17:46:19', '2023-08-24 17:46:19', '<!-- wp:paragraph -->\n<p>This php meet is for all php dveelopers out there looking to learn what is the next step in their lives.</p>\n<!-- /wp:paragraph -->', 'Php Meetup', '', 'publish', 'closed', 'closed', '', 'php-meetup', '', '', '2023-09-05 03:37:07', '2023-09-05 03:37:07', '', 0, 'http://bytebookexchange.com?post_type=event&#038;p=58', 0, 'event', '', 0),
(59, 1, '2023-08-24 18:14:17', '2023-08-24 18:14:17', '<!-- wp:paragraph -->\n<p>The event is highly focused on backend with Java and we will discuss all about popular frameworks and when is the best time to use.</p>\n<!-- /wp:paragraph -->', 'Java Backend talks', '', 'publish', 'closed', 'closed', '', 'java-backend-talks', '', '', '2023-08-25 17:38:37', '2023-08-25 17:38:37', '', 0, 'http://bytebookexchange.com?post_type=event&#038;p=59', 0, 'event', '', 0),
(60, 1, '2023-08-24 18:23:49', '2023-08-24 18:23:49', '', 'Past Events', '', 'publish', 'closed', 'closed', '', 'past-events', '', '', '2023-08-24 18:23:49', '2023-08-24 18:23:49', '', 0, 'http://bytebookexchange.com?page_id=60', 0, 'page', '', 0),
(61, 1, '2023-08-24 18:23:49', '2023-08-24 18:23:49', '', 'Past Events', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2023-08-24 18:23:49', '2023-08-24 18:23:49', '', 60, 'http://bytebookexchange.com?p=61', 0, 'revision', '', 0),
(62, 1, '2023-08-24 18:32:38', '2023-08-24 18:32:38', '<!-- wp:paragraph -->\n<p>Hey all developers, it\'s time to celebrate, let\'s meet on New year even and celebrate</p>\n<!-- /wp:paragraph -->', 'New Year 2022', '', 'publish', 'closed', 'closed', '', 'new-year-2022', '', '', '2023-08-24 18:32:38', '2023-08-24 18:32:38', '', 0, 'http://bytebookexchange.com?post_type=event&#038;p=62', 0, 'event', '', 0),
(63, 1, '2023-08-24 22:26:02', '2023-08-24 22:26:02', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<!-- /wp:paragraph -->', 'Problem Solving', '', 'publish', 'closed', 'closed', '', 'problem-solving', '', '', '2023-08-24 22:26:02', '2023-08-24 22:26:02', '', 0, 'http://bytebookexchange.com?post_type=program&#038;p=63', 0, 'program', '', 0),
(64, 1, '2023-08-24 22:26:23', '2023-08-24 22:26:23', '', 'BackEnd', '', 'publish', 'closed', 'closed', '', 'backend', '', '', '2023-09-02 17:24:37', '2023-09-02 17:24:37', '', 0, 'http://bytebookexchange.com?post_type=program&#038;p=64', 0, 'program', '', 0),
(65, 1, '2023-08-24 22:26:44', '2023-08-24 22:26:44', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<!-- /wp:paragraph -->', 'FrontEnd', '', 'publish', 'closed', 'closed', '', 'frontend', '', '', '2023-08-29 05:19:22', '2023-08-29 05:19:22', '', 0, 'http://bytebookexchange.com?post_type=program&#038;p=65', 0, 'program', '', 0),
(66, 1, '2023-08-24 22:49:09', '2023-08-24 22:49:09', 'a:8:{s:8:"location";a:2:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"event";}}i:1;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:10:"instructor";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Related Programs', 'related-programs', 'publish', 'closed', 'closed', '', 'group_64e7dd1db66e1', '', '', '2023-08-26 04:08:28', '2023-08-26 04:08:28', '', 0, 'http://bytebookexchange.com?post_type=acf-field-group&#038;p=66', 0, 'acf-field-group', '', 0),
(67, 1, '2023-08-24 22:49:09', '2023-08-24 22:49:09', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:7:"program";}s:11:"post_status";s:0:"";s:8:"taxonomy";s:0:"";s:7:"filters";a:1:{i:0;s:6:"search";}s:13:"return_format";s:6:"object";s:3:"min";s:0:"";s:3:"max";s:0:"";s:8:"elements";s:0:"";s:13:"bidirectional";i:0;s:20:"bidirectional_target";a:0:{}}', 'Related Program(s)', 'related_programs', 'publish', 'closed', 'closed', '', 'field_64e7dd20a1850', '', '', '2023-08-24 22:49:09', '2023-08-24 22:49:09', '', 66, 'http://bytebookexchange.com?post_type=acf-field&p=67', 0, 'acf-field', '', 0),
(68, 1, '2023-08-26 03:55:20', '2023-08-26 03:55:20', '<!-- wp:paragraph -->\n<p>Proactive individual with more than three years of experience in creating solutions for clients\' website needs. With knowledge of website development, designing and debugging, seeking a challenging position where I can implement my learnings and attention to detail. Looking for an opportunity where my contributions to the organization can assist in driving more business along with personal growth.</p>\n<!-- /wp:paragraph -->', 'Akshay Sharma', '', 'publish', 'closed', 'closed', '', 'akshay-sharma', '', '', '2023-09-09 04:34:12', '2023-09-09 04:34:12', '', 0, 'http://bytebookexchange.com?post_type=instructor&#038;p=68', 0, 'instructor', '', 0),
(69, 1, '2023-08-26 03:55:55', '2023-08-26 03:55:55', '<!-- wp:paragraph -->\n<p>Helloo Guys this is the sample text for mr.Sunny here for now</p>\n<!-- /wp:paragraph -->', 'Mr. Sunny', '', 'publish', 'closed', 'closed', '', 'mr-sunny', '', '', '2023-08-26 04:40:15', '2023-08-26 04:40:15', '', 0, 'http://bytebookexchange.com?post_type=instructor&#038;p=69', 0, 'instructor', '', 0),
(70, 1, '2023-08-26 04:32:41', '2023-08-26 04:32:41', '', 'my_profile_pic', '', 'inherit', 'open', 'closed', '', 'my_profile_pic', '', '', '2023-08-26 04:32:41', '2023-08-26 04:32:41', '', 68, 'http://bytebookexchange.comwp-content/uploads/2023/08/my_profile_pic.jpg', 0, 'attachment', 'image/jpeg', 0),
(72, 1, '2023-08-26 04:40:09', '2023-08-26 04:40:09', '', 'my professional pic', '', 'inherit', 'open', 'closed', '', 'my-professional-pic', '', '', '2023-08-26 04:40:09', '2023-08-26 04:40:09', '', 69, 'http://bytebookexchange.comwp-content/uploads/2023/08/my-professional-pic.png', 0, 'attachment', 'image/png', 0),
(73, 1, '2023-08-26 05:16:09', '2023-08-26 05:16:09', 'a:8:{s:8:"location";a:2:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}i:1;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"!=";s:5:"value";s:4:"post";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Page Banner', 'page-banner', 'publish', 'closed', 'closed', '', 'group_64e98a2b5502e', '', '', '2023-08-26 05:16:12', '2023-08-26 05:16:12', '', 0, 'http://bytebookexchange.com?post_type=acf-field-group&#038;p=73', 0, 'acf-field-group', '', 0),
(74, 1, '2023-08-26 05:16:09', '2023-08-26 05:16:09', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Page Banner Subtitle', 'page_banner_subtitle', 'publish', 'closed', 'closed', '', 'field_64e98a3e93f11', '', '', '2023-08-26 05:16:09', '2023-08-26 05:16:09', '', 73, 'http://bytebookexchange.com?post_type=acf-field&p=74', 0, 'acf-field', '', 0),
(75, 1, '2023-08-26 05:16:09', '2023-08-26 05:16:09', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:6:"medium";}', 'Page Banner Background Image', 'page_banner_background_image', 'publish', 'closed', 'closed', '', 'field_64e98a5293f12', '', '', '2023-08-26 05:16:09', '2023-08-26 05:16:09', '', 73, 'http://bytebookexchange.com?post_type=acf-field&p=75', 1, 'acf-field', '', 0),
(76, 1, '2023-08-26 05:19:03', '2023-08-26 05:19:03', '', 'cover-image', '', 'inherit', 'open', 'closed', '', 'cover-image', '', '', '2023-08-26 05:19:03', '2023-08-26 05:19:03', '', 68, 'http://bytebookexchange.comwp-content/uploads/2023/08/cover-image.png', 0, 'attachment', 'image/png', 0),
(78, 1, '2023-08-26 16:48:26', '2023-08-26 16:48:26', '<!-- wp:paragraph -->\n<p>This is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsum</p>\n<!-- /wp:paragraph -->', 'About Us', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2023-08-26 16:48:26', '2023-08-26 16:48:26', '', 18, 'http://bytebookexchange.com?p=78', 0, 'revision', '', 0),
(79, 1, '2023-08-26 16:52:17', '2023-08-26 16:52:17', '', 'knowledge', '', 'inherit', 'open', 'closed', '', 'knowledge-2', '', '', '2023-08-26 16:52:17', '2023-08-26 16:52:17', '', 18, 'http://bytebookexchange.comwp-content/uploads/2023/08/knowledge-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(80, 1, '2023-08-26 16:52:29', '2023-08-26 16:52:29', '<!-- wp:paragraph -->\n<p>This is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsumThis is the about us content. Lorem ipsum</p>\n<!-- /wp:paragraph -->', 'About Us', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2023-08-26 16:52:29', '2023-08-26 16:52:29', '', 18, 'http://bytebookexchange.com?p=80', 0, 'revision', '', 0),
(81, 1, '2023-08-27 18:49:21', '2023-08-27 18:49:21', '', 'events', '', 'inherit', 'open', 'closed', '', 'events', '', '', '2023-08-27 18:49:21', '2023-08-27 18:49:21', '', 49, 'http://bytebookexchange.comwp-content/uploads/2023/08/events.jpg', 0, 'attachment', 'image/jpeg', 0),
(82, 1, '2023-08-29 02:47:00', '2023-08-29 02:47:00', '<!-- wp:paragraph -->\n<p>A beautiful campus in the heart of downtown</p>\n<!-- /wp:paragraph -->', 'Toronto West', '', 'publish', 'closed', 'closed', '', 'toronto-west', '', '', '2023-08-29 04:47:16', '2023-08-29 04:47:16', '', 0, 'http://bytebookexchange.com?post_type=campus&#038;p=82', 0, 'campus', '', 0),
(83, 1, '2023-08-29 02:47:35', '2023-08-29 02:47:35', '<!-- wp:paragraph -->\n<p>A beautiful campus located in New York, USA </p>\n<!-- /wp:paragraph -->', 'New York', '', 'publish', 'closed', 'closed', '', 'mumbai-east', '', '', '2023-08-29 04:46:51', '2023-08-29 04:46:51', '', 0, 'http://bytebookexchange.com?post_type=campus&#038;p=83', 0, 'campus', '', 0),
(86, 1, '2023-08-29 02:52:41', '2023-08-29 02:52:41', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:6:"campus";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Map Location', 'map-location', 'publish', 'closed', 'closed', '', 'group_64ed5d284a37f', '', '', '2023-08-29 03:41:47', '2023-08-29 03:41:47', '', 0, 'http://bytebookexchange.com?post_type=acf-field-group&#038;p=86', 0, 'acf-field-group', '', 0),
(88, 1, '2023-08-29 02:52:41', '2023-08-29 02:52:41', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Map', 'map_location', 'publish', 'closed', 'closed', '', 'field_64ed5d30ea9b6', '', '', '2023-08-29 03:22:54', '2023-08-29 03:22:54', '', 86, 'http://bytebookexchange.com?post_type=acf-field&#038;p=88', 0, 'acf-field', '', 0),
(89, 1, '2023-08-29 05:14:48', '2023-08-29 05:14:48', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:7:"program";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Related Campus(es)', 'related-campuses', 'publish', 'closed', 'closed', '', 'group_64ed7e2794a67', '', '', '2023-08-29 05:14:48', '2023-08-29 05:14:48', '', 0, 'http://bytebookexchange.com?post_type=acf-field-group&#038;p=89', 0, 'acf-field-group', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(90, 1, '2023-08-29 05:14:48', '2023-08-29 05:14:48', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:6:"campus";}s:11:"post_status";s:0:"";s:8:"taxonomy";s:0:"";s:7:"filters";a:1:{i:0;s:6:"search";}s:13:"return_format";s:6:"object";s:3:"min";s:0:"";s:3:"max";s:0:"";s:8:"elements";s:0:"";s:13:"bidirectional";i:0;s:20:"bidirectional_target";a:0:{}}', 'Related Campus(es)', 'related_campus', 'publish', 'closed', 'closed', '', 'field_64ed7e28c5486', '', '', '2023-08-29 05:14:48', '2023-08-29 05:14:48', '', 89, 'http://bytebookexchange.com?post_type=acf-field&p=90', 0, 'acf-field', '', 0),
(91, 1, '2023-08-29 21:37:47', '2023-08-29 21:37:47', '<!-- wp:quote -->\n<blockquote class="wp-block-quote"><!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<!-- /wp:paragraph --></blockquote>\n<!-- /wp:quote -->', 'JavaScript is cool', '', 'publish', 'open', 'open', '', 'javascript-is-cool', '', '', '2023-08-29 21:37:49', '2023-08-29 21:37:49', '', 0, 'http://bytebookexchange.com?p=91', 0, 'post', '', 0),
(92, 1, '2023-08-29 21:37:47', '2023-08-29 21:37:47', '<!-- wp:quote -->\n<blockquote class="wp-block-quote"><!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<!-- /wp:paragraph --></blockquote>\n<!-- /wp:quote -->', 'JavaScript is cool', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2023-08-29 21:37:47', '2023-08-29 21:37:47', '', 91, 'http://bytebookexchange.com?p=92', 0, 'revision', '', 0),
(93, 1, '2023-08-29 22:12:00', '2023-08-29 22:12:00', '<!-- wp:quote -->\n<blockquote class="wp-block-quote"><!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<!-- /wp:paragraph --></blockquote>\n<!-- /wp:quote -->', 'We Won an Award', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2023-08-29 22:12:00', '2023-08-29 22:12:00', '', 45, 'http://bytebookexchange.com?p=93', 0, 'revision', '', 0),
(94, 1, '2023-09-02 17:22:31', '2023-09-02 17:22:31', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:7:"program";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Main Body Content', 'main-body-content', 'publish', 'closed', 'closed', '', 'group_64f36ecdcc799', '', '', '2023-09-02 17:22:31', '2023-09-02 17:22:31', '', 0, 'http://bytebookexchange.com?post_type=acf-field-group&#038;p=94', 0, 'acf-field-group', '', 0),
(95, 1, '2023-09-02 17:22:31', '2023-09-02 17:22:31', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Main Body Content', 'main_body_content', 'publish', 'closed', 'closed', '', 'field_64f36ed1ce4b6', '', '', '2023-09-02 17:22:31', '2023-09-02 17:22:31', '', 94, 'http://bytebookexchange.com?post_type=acf-field&p=95', 0, 'acf-field', '', 0),
(96, 1, '2023-09-02 17:22:31', '2023-09-02 17:22:31', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', '', '', 'publish', 'closed', 'closed', '', 'field_64f36ed8ce4b7', '', '', '2023-09-02 17:22:31', '2023-09-02 17:22:31', '', 94, 'http://bytebookexchange.com?post_type=acf-field&p=96', 1, 'acf-field', '', 0),
(97, 1, '2023-09-06 05:53:28', '2023-09-06 05:53:28', '', 'Search', '', 'publish', 'closed', 'closed', '', 'search', '', '', '2023-09-06 05:53:29', '2023-09-06 05:53:29', '', 0, 'http://bytebookexchange.com?page_id=97', 0, 'page', '', 0),
(98, 1, '2023-09-06 05:53:28', '2023-09-06 05:53:28', '', 'Search', '', 'inherit', 'closed', 'closed', '', '97-revision-v1', '', '', '2023-09-06 05:53:28', '2023-09-06 05:53:28', '', 97, 'http://bytebookexchange.com?p=98', 0, 'revision', '', 0),
(99, 1, '2023-09-06 17:50:09', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-09-06 17:50:09', '0000-00-00 00:00:00', '', 0, 'http://bytebookexchange.com?p=99', 0, 'post', '', 0),
(100, 2, '2023-09-06 17:53:53', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-09-06 17:53:53', '0000-00-00 00:00:00', '', 0, 'http://bytebookexchange.com?p=100', 0, 'post', '', 0),
(101, 2, '2023-09-06 18:04:49', '2023-09-06 18:04:49', '', 'Understanding Arrays', '', 'publish', 'closed', 'closed', '', 'understanding-arrays', '', '', '2023-09-06 18:04:49', '2023-09-06 18:04:49', '', 0, 'http://bytebookexchange.com?post_type=event&#038;p=101', 0, 'event', '', 0),
(102, 1, '2023-09-06 20:59:05', '2023-09-06 20:59:05', '', 'My Notes', '', 'publish', 'closed', 'closed', '', 'my-notes', '', '', '2023-09-06 20:59:05', '2023-09-06 20:59:05', '', 0, 'http://bytebookexchange.com?page_id=102', 0, 'page', '', 0),
(103, 1, '2023-09-06 20:59:05', '2023-09-06 20:59:05', '', 'My Notes', '', 'inherit', 'closed', 'closed', '', '102-revision-v1', '', '', '2023-09-06 20:59:05', '2023-09-06 20:59:05', '', 102, 'http://bytebookexchange.com?p=103', 0, 'revision', '', 0),
(104, 1, '2023-09-06 21:14:10', '2023-09-06 21:14:10', '<!-- wp:paragraph -->\n<p>Learned about array and they do work behind the scenes.</p>\n<!-- /wp:paragraph -->', 'JavaScript lecture #4', '', 'private', 'closed', 'closed', '', 'javascript-lecture-4', '', '', '2023-09-08 04:54:57', '2023-09-08 04:54:57', '', 0, 'http://bytebookexchange.com?post_type=note&#038;p=104', 0, 'note', '', 0),
(105, 1, '2023-09-06 21:14:50', '2023-09-06 21:14:50', 'Working and implementation of hashmaps. Learned implementation as well as common questions. Enjoyed it.\n', 'HashMaps', '', 'private', 'closed', 'closed', '', 'hashmaps', '', '', '2023-09-08 04:54:57', '2023-09-08 04:54:57', '', 0, 'http://bytebookexchange.com?post_type=note&#038;p=105', 0, 'note', '', 0),
(106, 1, '2023-09-07 03:36:27', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-09-07 03:36:27', '0000-00-00 00:00:00', '', 0, 'http://bytebookexchange.com?post_type=note&p=106', 0, 'note', '', 0),
(107, 1, '2023-09-07 17:18:23', '2023-09-07 17:18:23', '<!-- wp:paragraph -->\n<p>Learned about functions and how do they work.</p>\n<!-- /wp:paragraph -->', 'JavaScript lecture #4', '', 'trash', 'closed', 'closed', '', 'javascript-lecture-4__trashed', '', '', '2023-09-08 03:52:47', '2023-09-08 03:52:47', '', 0, 'http://bytebookexchange.com?post_type=note&#038;p=107', 0, 'note', '', 0),
(108, 1, '2023-09-08 04:23:29', '2023-09-08 04:23:29', 'Learned that JavaScript has only pass by value and no pass by reference.', 'Functions in JavaScript', '', 'private', 'closed', 'closed', '', 'functions-in-javascript', '', '', '2023-09-08 05:22:15', '2023-09-08 05:22:15', '', 0, 'http://bytebookexchange.comnote/functions-in-javascript/', 0, 'note', '', 0),
(109, 3, '2023-09-08 05:20:14', '2023-09-08 05:20:14', 'shrsthbvm yes', 'Edited sklfnkosbnmb', '', 'trash', 'closed', 'closed', '', 'sklfnkos__trashed', '', '', '2023-09-08 06:09:37', '2023-09-08 06:09:37', '', 0, 'http://bytebookexchange.comnote/sklfnkos/', 0, 'note', '', 0),
(110, 3, '2023-09-08 06:11:03', '2023-09-08 06:11:03', 'alert("Hello");', '', '', 'trash', 'closed', 'closed', '', '110__trashed', '', '', '2023-09-08 06:11:06', '2023-09-08 06:11:06', '', 0, 'http://bytebookexchange.comnote/110/', 0, 'note', '', 0),
(111, 3, '2023-09-08 06:16:23', '2023-09-08 06:16:23', '<p>Hello</p>', 'subscriber html', '', 'trash', 'closed', 'closed', '', 'subscriber-html__trashed', '', '', '2023-09-08 06:17:11', '2023-09-08 06:17:11', '', 0, 'http://bytebookexchange.comnote/subscriber-html/', 0, 'note', '', 0),
(112, 3, '2023-09-08 06:19:39', '2023-09-08 06:19:39', 'Hwello', '', '', 'trash', 'closed', 'closed', '', '112__trashed', '', '', '2023-09-08 06:19:42', '2023-09-08 06:19:42', '', 0, 'http://bytebookexchange.comnote/112/', 0, 'note', '', 0),
(113, 3, '2023-09-08 06:24:31', '2023-09-08 06:24:31', 'afsf', 'sdrfgdrs', '', 'trash', 'closed', 'closed', '', 'sdrfgdrs__trashed', '', '', '2023-09-08 06:25:01', '2023-09-08 06:25:01', '', 0, 'http://bytebookexchange.comnote/sdrfgdrs/', 0, 'note', '', 0),
(114, 3, '2023-09-08 06:24:34', '2023-09-08 06:24:34', 'dsgd', 'dshbsdf', '', 'trash', 'closed', 'closed', '', 'dshbsdf__trashed', '', '', '2023-09-08 06:25:02', '2023-09-08 06:25:02', '', 0, 'http://bytebookexchange.comnote/dshbsdf/', 0, 'note', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(115, 3, '2023-09-08 06:24:41', '2023-09-08 06:24:41', 'dfhdfg', 'dsfghdf', '', 'trash', 'closed', 'closed', '', 'dsfghdf__trashed', '', '', '2023-09-08 06:25:03', '2023-09-08 06:25:03', '', 0, 'http://bytebookexchange.comnote/dsfghdf/', 0, 'note', '', 0),
(116, 3, '2023-09-08 06:24:57', '2023-09-08 06:24:57', 'dsfg', 'sdgfhsdfh', '', 'trash', 'closed', 'closed', '', 'sdgfhsdfh__trashed', '', '', '2023-09-08 06:25:29', '2023-09-08 06:25:29', '', 0, 'http://bytebookexchange.comnote/sdgfhsdfh/', 0, 'note', '', 0),
(117, 3, '2023-09-08 06:25:18', '2023-09-08 06:25:18', 'asrgasd', 'safgs', '', 'trash', 'closed', 'closed', '', 'safgs__trashed', '', '', '2023-09-08 06:25:31', '2023-09-08 06:25:31', '', 0, 'http://bytebookexchange.comnote/safgs/', 0, 'note', '', 0),
(118, 3, '2023-09-08 06:25:26', '2023-09-08 06:25:26', 'gadgadg', 'agaegeasd', '', 'trash', 'closed', 'closed', '', 'agaegeasd__trashed', '', '', '2023-09-08 06:25:33', '2023-09-08 06:25:33', '', 0, 'http://bytebookexchange.comnote/agaegeasd/', 0, 'note', '', 0),
(119, 3, '2023-09-08 06:26:43', '2023-09-08 06:26:43', 'Wf', 'QAFDQW', '', 'trash', 'closed', 'closed', '', 'qafdqw__trashed', '', '', '2023-09-08 06:36:23', '2023-09-08 06:36:23', '', 0, 'http://bytebookexchange.comnote/qafdqw/', 0, 'note', '', 0),
(120, 3, '2023-09-08 06:26:46', '2023-09-08 06:26:46', 'wfW', 'Wef', '', 'trash', 'closed', 'closed', '', 'wef__trashed', '', '', '2023-09-08 06:27:12', '2023-09-08 06:27:12', '', 0, 'http://bytebookexchange.comnote/wef/', 0, 'note', '', 0),
(121, 3, '2023-09-08 06:26:52', '2023-09-08 06:26:52', 'wefwef', 'WFWEF', '', 'trash', 'closed', 'closed', '', 'wfwef__trashed', '', '', '2023-09-08 06:27:09', '2023-09-08 06:27:09', '', 0, 'http://bytebookexchange.comnote/wfwef/', 0, 'note', '', 0),
(122, 3, '2023-09-08 06:27:06', '2023-09-08 06:27:06', 'PPPPP', 'PP', '', 'trash', 'closed', 'closed', '', 'pp__trashed', '', '', '2023-09-08 06:27:10', '2023-09-08 06:27:10', '', 0, 'http://bytebookexchange.comnote/pp/', 0, 'note', '', 0),
(123, 3, '2023-09-08 06:31:14', '2023-09-08 06:31:14', 'fasfgas', 'safsd', '', 'trash', 'closed', 'closed', '', 'safsd__trashed', '', '', '2023-09-08 06:36:22', '2023-09-08 06:36:22', '', 0, 'http://bytebookexchange.comnote/safsd/', 0, 'note', '', 0),
(124, 3, '2023-09-08 06:31:18', '2023-09-08 06:31:18', 'fsadfsadf', 'sdfsa', '', 'trash', 'closed', 'closed', '', 'sdfsa__trashed', '', '', '2023-09-08 06:36:21', '2023-09-08 06:36:21', '', 0, 'http://bytebookexchange.comnote/sdfsa/', 0, 'note', '', 0),
(125, 3, '2023-09-08 06:36:37', '2023-09-08 06:36:37', 'Forst', 'first', '', 'trash', 'closed', 'closed', '', 'first__trashed', '', '', '2023-09-08 06:42:06', '2023-09-08 06:42:06', '', 0, 'http://bytebookexchange.comnote/first/', 0, 'note', '', 0),
(126, 3, '2023-09-08 06:36:45', '2023-09-08 06:36:45', '2nd', 'second', '', 'trash', 'closed', 'closed', '', 'second__trashed', '', '', '2023-09-08 06:37:22', '2023-09-08 06:37:22', '', 0, 'http://bytebookexchange.comnote/second/', 0, 'note', '', 0),
(127, 3, '2023-09-08 06:36:52', '2023-09-08 06:36:52', '3rd', 'third', '', 'trash', 'closed', 'closed', '', 'third__trashed', '', '', '2023-09-08 06:37:21', '2023-09-08 06:37:21', '', 0, 'http://bytebookexchange.comnote/third/', 0, 'note', '', 0),
(128, 3, '2023-09-08 06:37:30', '2023-09-08 06:37:30', 'fifth', 'fifth', '', 'trash', 'closed', 'closed', '', 'fifth__trashed', '', '', '2023-09-08 06:37:42', '2023-09-08 06:37:42', '', 0, 'http://bytebookexchange.comnote/fifth/', 0, 'note', '', 0),
(129, 3, '2023-09-08 06:38:21', '2023-09-08 06:38:21', '2md', 'second', '', 'trash', 'closed', 'closed', '', 'second__trashed-2', '', '', '2023-09-08 06:42:04', '2023-09-08 06:42:04', '', 0, 'http://bytebookexchange.comnote/second/', 0, 'note', '', 0),
(130, 3, '2023-09-08 06:38:29', '2023-09-08 06:38:29', '3rd', 'third', '', 'trash', 'closed', 'closed', '', 'third__trashed-2', '', '', '2023-09-08 06:39:03', '2023-09-08 06:39:03', '', 0, 'http://bytebookexchange.comnote/third/', 0, 'note', '', 0),
(131, 3, '2023-09-08 06:39:05', '2023-09-08 06:39:05', 'afwqeAFWE', 'asda', '', 'trash', 'closed', 'closed', '', 'asda__trashed', '', '', '2023-09-08 06:42:03', '2023-09-08 06:42:03', '', 0, 'http://bytebookexchange.comnote/asda/', 0, 'note', '', 0),
(132, 3, '2023-09-08 06:42:13', '2023-09-08 06:42:13', 'qwfwqe', 'qqwd', '', 'private', 'closed', 'closed', '', 'qqwd', '', '', '2023-09-08 06:42:13', '2023-09-08 06:42:13', '', 0, 'http://bytebookexchange.comnote/qqwd/', 0, 'note', '', 0),
(133, 3, '2023-09-08 06:42:17', '2023-09-08 06:42:17', 'wefw', 'wefwqf', '', 'private', 'closed', 'closed', '', 'wefwqf', '', '', '2023-09-08 06:42:17', '2023-09-08 06:42:17', '', 0, 'http://bytebookexchange.comnote/wefwqf/', 0, 'note', '', 0),
(134, 3, '2023-09-08 06:42:21', '2023-09-08 06:42:21', 'wefweqf', 'wefweq', '', 'trash', 'closed', 'closed', '', 'wefweq__trashed', '', '', '2023-09-08 06:47:57', '2023-09-08 06:47:57', '', 0, 'http://bytebookexchange.comnote/wefweq/', 0, 'note', '', 0),
(135, 3, '2023-09-08 06:48:02', '2023-09-08 06:48:02', 'gerger', 'erger', '', 'trash', 'closed', 'closed', '', 'erger__trashed', '', '', '2023-09-08 07:04:29', '2023-09-08 07:04:29', '', 0, 'http://bytebookexchange.comnote/erger/', 0, 'note', '', 0),
(136, 3, '2023-09-08 07:04:30', '2023-09-08 07:04:30', 'yutilyu', 'ylkiutyl', '', 'trash', 'closed', 'closed', '', 'ylkiutyl__trashed', '', '', '2023-09-08 07:04:37', '2023-09-08 07:04:37', '', 0, 'http://bytebookexchange.comnote/ylkiutyl/', 0, 'note', '', 0),
(137, 3, '2023-09-08 07:04:38', '2023-09-08 07:04:38', '', '', '', 'trash', 'closed', 'closed', '', '137__trashed', '', '', '2023-09-08 07:04:41', '2023-09-08 07:04:41', '', 0, 'http://bytebookexchange.comnote/137/', 0, 'note', '', 0),
(138, 3, '2023-09-08 07:05:21', '2023-09-08 07:05:21', 'asdcas', 'ASFasdf', '', 'private', 'closed', 'closed', '', 'asfasdf', '', '', '2023-09-08 07:05:21', '2023-09-08 07:05:21', '', 0, 'http://bytebookexchange.comnote/asfasdf/', 0, 'note', '', 0),
(139, 3, '2023-09-08 07:08:19', '2023-09-08 07:08:19', 'fdsbdf', 'dzvfd', '', 'private', 'closed', 'closed', '', 'dzvfd', '', '', '2023-09-08 07:08:19', '2023-09-08 07:08:19', '', 0, 'http://bytebookexchange.comnote/dzvfd/', 0, 'note', '', 0),
(140, 3, '2023-09-08 07:08:21', '2023-09-08 07:08:21', 'dsbdf', 'dfbdfb', '', 'private', 'closed', 'closed', '', 'dfbdfb', '', '', '2023-09-08 07:08:21', '2023-09-08 07:08:21', '', 0, 'http://bytebookexchange.comnote/dfbdfb/', 0, 'note', '', 0),
(141, 1, '2023-09-09 04:23:29', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-09-09 04:23:29', '0000-00-00 00:00:00', '', 0, 'http://bytebookexchange.com?post_type=like&p=141', 0, 'like', '', 0),
(142, 1, '2023-09-09 04:25:35', '2023-09-09 04:25:35', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"like";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Liked Instructor ID', 'liked-instructor-id', 'publish', 'closed', 'closed', '', 'group_64fbf366e477f', '', '', '2023-09-09 04:38:13', '2023-09-09 04:38:13', '', 0, 'http://bytebookexchange.com?post_type=acf-field-group&#038;p=142', 0, 'acf-field-group', '', 0),
(143, 1, '2023-09-09 04:25:35', '2023-09-09 04:25:35', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:11:"placeholder";s:0:"";s:4:"step";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Liked Instructor ID', 'liked_instructor_id', 'publish', 'closed', 'closed', '', 'field_64fbf3696d186', '', '', '2023-09-09 04:38:13', '2023-09-09 04:38:13', '', 142, 'http://bytebookexchange.com?post_type=acf-field&#038;p=143', 0, 'acf-field', '', 0),
(144, 1, '2023-09-09 04:25:35', '2023-09-09 04:25:35', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', '', '', 'publish', 'closed', 'closed', '', 'field_64fbf3766d187', '', '', '2023-09-09 04:25:35', '2023-09-09 04:25:35', '', 142, 'http://bytebookexchange.com?post_type=acf-field&p=144', 1, 'acf-field', '', 0),
(145, 1, '2023-09-09 04:25:42', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-09-09 04:25:42', '0000-00-00 00:00:00', '', 0, 'http://bytebookexchange.com?post_type=like&p=145', 0, 'like', '', 0),
(147, 1, '2023-09-09 04:39:28', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-09-09 04:39:28', '0000-00-00 00:00:00', '', 0, 'http://bytebookexchange.com?post_type=like&p=147', 0, 'like', '', 0),
(164, 1, '2023-09-12 00:56:32', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-09-12 00:56:32', '0000-00-00 00:00:00', '', 0, 'http://bytebookexchange.com?p=164', 0, 'post', '', 0),
(165, 1, '2023-09-12 18:37:28', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-09-12 18:37:28', '0000-00-00 00:00:00', '', 0, 'http://bytebookexchange.com?post_type=post_like&p=165', 0, 'post_like', '', 0),
(166, 1, '2023-09-12 18:37:32', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-09-12 18:37:32', '0000-00-00 00:00:00', '', 0, 'http://bytebookexchange.com?post_type=post_like&p=166', 0, 'post_like', '', 0),
(167, 1, '2023-09-12 18:39:06', '2023-09-12 18:39:06', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:9:"post_like";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Liked Post ID', 'liked-post-id', 'publish', 'closed', 'closed', '', 'group_6500b00d9b18c', '', '', '2023-09-12 18:39:06', '2023-09-12 18:39:06', '', 0, 'http://bytebookexchange.com?post_type=acf-field-group&#038;p=167', 0, 'acf-field-group', '', 0),
(168, 1, '2023-09-12 18:39:06', '2023-09-12 18:39:06', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:11:"placeholder";s:0:"";s:4:"step";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Liked Post ID', 'liked_post_id', 'publish', 'closed', 'closed', '', 'field_6500b0109776d', '', '', '2023-09-12 18:39:06', '2023-09-12 18:39:06', '', 167, 'http://bytebookexchange.com?post_type=acf-field&p=168', 0, 'acf-field', '', 0),
(208, 3, '2023-09-12 23:55:50', '2023-09-12 23:55:50', '', 'Test Like', '', 'publish', 'closed', 'closed', '', 'test-like', '', '', '2023-09-12 23:55:50', '2023-09-12 23:55:50', '', 0, 'http://bytebookexchange.com?p=208', 0, 'post_liked', '', 0),
(209, 1, '2023-09-12 23:56:16', '2023-09-12 23:56:16', '', 'Test Like', '', 'publish', 'closed', 'closed', '', 'test-like-2', '', '', '2023-09-12 23:56:16', '2023-09-12 23:56:16', '', 0, 'http://bytebookexchange.com?p=209', 0, 'post_liked', '', 0),
(218, 1, '2023-09-13 00:45:06', '2023-09-13 00:45:06', '', 'New Post Like', '', 'publish', 'closed', 'closed', '', 'new-post-like', '', '', '2023-09-13 00:45:06', '2023-09-13 00:45:06', '', 0, 'http://bytebookexchange.compost_like/new-post-like/', 0, 'post_like', '', 0),
(234, 1, '2023-09-13 03:00:00', '2023-09-13 03:00:00', '', 'another test', '', 'publish', 'closed', 'closed', '', 'another-test', '', '', '2023-09-13 03:00:00', '2023-09-13 03:00:00', '', 0, 'http://bytebookexchange.comlike/another-test/', 0, 'like', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(7, 1, 0),
(9, 1, 0),
(30, 2, 0),
(32, 2, 0),
(37, 3, 0),
(38, 3, 0),
(39, 4, 0),
(40, 4, 0),
(45, 5, 0),
(91, 1, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 4),
(2, 2, 'nav_menu', '', 0, 2),
(3, 3, 'nav_menu', '', 0, 2),
(4, 4, 'nav_menu', '', 0, 2),
(5, 5, 'category', 'We love to blog about our blogs', 0, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'My Main Header Menu', 'my-main-header-menu', 0),
(3, 'FooterOneLocationMenu', 'footeronelocationmenu', 0),
(4, 'FooterMenuLocationTwo', 'footermenulocationtwo', 0),
(5, 'Awards', 'awards', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'Akshay'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', 'A developer by nature.'),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:5:{s:64:"bd356a0ef31b13cbf111b1e38c403ea7cd5682901af8d63f868aac0ded15dad3";a:4:{s:10:"expiration";i:1694590784;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36";s:5:"login";i:1694417984;}s:64:"5b53dac258b90f81c40bd473e624a17445bca7be64a8ab90932631f17f6ee478";a:4:{s:10:"expiration";i:1694590788;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36";s:5:"login";i:1694417988;}s:64:"2040b1b28a2fe927a062f029a5948ce97d971cb3bb40296182ff806d17fda133";a:4:{s:10:"expiration";i:1694652990;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36";s:5:"login";i:1694480190;}s:64:"c7bb37552c6dbd2e26e5f9e8a8110c4a921aeb873f71fd1683815fe87e93f85f";a:4:{s:10:"expiration";i:1694716302;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36";s:5:"login";i:1694543502;}s:64:"01bcd0f11beb32845f2b17fab22180d9049802b77863f14eb76ae6546fdc7aa6";a:4:{s:10:"expiration";i:1694744006;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36";s:5:"login";i:1694571206;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '164'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(19, 1, 'wp_persisted_preferences', 'a:2:{s:14:"core/edit-post";a:3:{s:26:"isComplementaryAreaVisible";b:1;s:12:"welcomeGuide";b:0;s:10:"openPanels";a:5:{i:0;s:11:"post-status";i:1;s:15:"page-attributes";i:2;s:23:"taxonomy-panel-category";i:3;s:12:"post-excerpt";i:4;s:14:"featured-image";}}s:9:"_modified";s:24:"2023-08-26T04:30:33.679Z";}'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(22, 1, 'nav_menu_recently_edited', '4'),
(23, 1, 'enable_custom_fields', '1'),
(24, 1, 'wp_user-settings', 'libraryContent=browse&editor=tinymce'),
(25, 1, 'wp_user-settings-time', '1693675384'),
(26, 1, 'closedpostboxes_campus', 'a:0:{}'),
(27, 1, 'metaboxhidden_campus', 'a:0:{}'),
(28, 2, 'nickname', 'sunny'),
(29, 2, 'first_name', 'Sunny'),
(30, 2, 'last_name', 'Sharma'),
(31, 2, 'description', ''),
(32, 2, 'rich_editing', 'true'),
(33, 2, 'syntax_highlighting', 'true'),
(34, 2, 'comment_shortcuts', 'false'),
(35, 2, 'admin_color', 'ectoplasm'),
(36, 2, 'use_ssl', '0'),
(37, 2, 'show_admin_bar_front', 'true'),
(38, 2, 'locale', ''),
(39, 2, 'wp_capabilities', 'a:2:{s:13:"event_planner";b:1;s:14:"campus_manager";b:1;}'),
(40, 2, 'wp_user_level', '0'),
(41, 2, 'dismissed_wp_pointers', ''),
(42, 2, 'session_tokens', 'a:1:{s:64:"02adbe4e727bf1f30f03b465e5f032f4ddde1ddbbf7f4059c31792c35dfc5137";a:4:{s:10:"expiration";i:1694195630;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36";s:5:"login";i:1694022830;}}'),
(43, 2, 'wp_dashboard_quick_press_last_post_id', '100'),
(44, 1, 'closedpostboxes_toplevel_page_members', 'a:0:{}'),
(45, 1, 'metaboxhidden_toplevel_page_members', 'a:0:{}'),
(46, 2, 'wp_persisted_preferences', 'a:2:{s:14:"core/edit-post";a:2:{s:26:"isComplementaryAreaVisible";b:1;s:12:"welcomeGuide";b:0;}s:9:"_modified";s:24:"2023-09-06T18:04:23.578Z";}'),
(47, 3, 'nickname', 'Tarun'),
(48, 3, 'first_name', ''),
(49, 3, 'last_name', ''),
(50, 3, 'description', ''),
(51, 3, 'rich_editing', 'true'),
(52, 3, 'syntax_highlighting', 'true'),
(53, 3, 'comment_shortcuts', 'false'),
(54, 3, 'admin_color', 'coffee'),
(55, 3, 'use_ssl', '0'),
(56, 3, 'show_admin_bar_front', 'true'),
(57, 3, 'locale', ''),
(58, 3, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}'),
(59, 3, 'wp_user_level', '0'),
(60, 3, 'default_password_nag', ''),
(64, 3, 'session_tokens', 'a:1:{s:64:"25cf28d444ed3d7dbe8475d9f3766dad839f72c09d8675121c92aabc52712458";a:4:{s:10:"expiration";i:1694724079;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36";s:5:"login";i:1694551279;}}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'akshay', '$P$BgT.k618pLkuKun7WDDDV4ey5THshQ.', 'akshay', 'akshaysharma5432@gmail.com', 'http://bytebookexchange', '2023-08-19 17:17:19', '', 0, 'Akshay'),
(2, 'sunny', '$P$BddZglAK5mzigTrkk51xJTFognZcKk1', 'sunny', 'akshaysharma543210@gmail.com', '', '2023-09-06 17:52:36', '1694022757:$P$BVhklLVfrA1lY9ohX1uFZNB7PFPit/0', 0, 'Sunny Sharma'),
(3, 'Tarun', '$P$B7NXMKbS7ki.sBBN9TKzA6rD0j3TR90', 'tarun', 'akshaysharma581995@gmail.com', '', '2023-09-06 18:24:19', '', 0, 'Tarun') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

